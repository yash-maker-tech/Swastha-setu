/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        teal: {
          deep: '#0F3D3E',
          primary: '#137A6E',
          mid: '#1A8A7D',
        },
        mint: {
          DEFAULT: '#6FD3BF',
          light: '#E7F0EC',
          soft: '#F0F7F4',
        },
        surface: {
          bg: '#F7F5EF',
          card: '#FFFFFF',
          border: '#D6E3DE',
        },
        ink: {
          DEFAULT: '#17302F',
          muted: '#52686A',
          subtle: '#82999B',
        },
        urgent: {
          DEFAULT: '#C73E1D',
          light: '#FDECE8',
          border: '#F8B4A6',
        }
      },
      fontFamily: {
        heading: ['Nunito', 'sans-serif'],
        sans: ['"Nunito Sans"', 'sans-serif'],
      },
      borderRadius: {
        '2xl': '1rem',
        '3xl': '1.5rem',
      },
      boxShadow: {
        'phone': '0 25px 60px -15px rgba(15, 61, 62, 0.25), 0 0 0 12px #2A3638',
        'soft': '0 4px 20px -2px rgba(15, 61, 62, 0.06)',
      }
    },
  },
  plugins: [],
}
