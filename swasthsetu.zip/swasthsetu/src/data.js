export const SYMPTOMS = [
  {
    id: 'fever',
    label: 'Fever',
    category: 'general',
    icon: 'Thermometer',
    description: 'High body temperature or chills',
  },
  {
    id: 'stomach_pain',
    label: 'Stomach pain',
    category: 'general',
    icon: 'Activity',
    description: 'Abdominal cramps or ache',
  },
  {
    id: 'headache',
    label: 'Headache',
    category: 'general',
    icon: 'Brain',
    description: 'Throbbing or persistent head ache',
  },
  {
    id: 'cough_cold',
    label: 'Cough & cold',
    category: 'general',
    icon: 'Wind',
    description: 'Runny nose, sore throat or cough',
  },
  {
    id: 'menstrual',
    label: 'Menstrual irregularities',
    category: 'women',
    icon: 'CalendarHeart',
    description: 'Irregular cycles or cramps',
  },
  {
    id: 'pregnancy',
    label: 'Pregnancy related',
    category: 'women',
    icon: 'Baby',
    description: 'Pre-natal queries or maternal health',
  },
  {
    id: 'acne_skin',
    label: 'Acne / Skin issues',
    category: 'skin',
    icon: 'Sparkles',
    description: 'Rashes, breakouts or allergies',
  },
  {
    id: 'back_joint_pain',
    label: 'Back or joint pain',
    category: 'ortho',
    icon: 'Bone',
    description: 'Spine stiffness or aching joints',
  },
  {
    id: 'mental_health',
    label: 'Mental health concerns',
    category: 'mental',
    icon: 'HeartPulse',
    description: 'Stress, low mood or anxiety',
  },
  {
    id: 'knee_pain',
    label: 'Knee pain',
    category: 'ortho',
    icon: 'Footprints',
    description: 'Sharp pain or swelling around knees',
  },
  {
    id: 'joint_stiffness',
    label: 'Joint stiffness',
    category: 'ortho',
    icon: 'ShieldAlert',
    description: 'Trouble bending or morning stiffness',
  },
  {
    id: 'difficulty_walking',
    label: 'Difficulty walking',
    category: 'ortho',
    icon: 'Accessibility',
    description: 'Limping or unsteady gait',
  },
  // Red flag symptoms
  {
    id: 'chest_pain',
    label: 'Chest pain',
    category: 'urgent',
    icon: 'AlertTriangle',
    isUrgent: true,
    description: 'Severe tightness or pressure in chest',
  },
  {
    id: 'difficulty_breathing',
    label: 'Difficulty breathing',
    category: 'urgent',
    icon: 'Flame',
    isUrgent: true,
    description: 'Shortness of breath or gasping',
  },
]

export const RED_FLAG_SYMPTOMS = ['chest_pain', 'difficulty_breathing']

export const SPECIALIST_MAPPINGS = {
  gynecologist: {
    title: 'Gynecologist',
    badge: 'Recommended Specialist',
    description: "Specializes in women's reproductive and menstrual health, fertility, and pregnancy care.",
    avatar: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&q=80&w=260',
    whyThisDoctor: 'Matches symptoms related to menstrual cycles, hormone health, or maternity.',
    otherSpecialists: [
      { name: 'Endocrinologist', reason: 'For deeper hormonal and thyroid evaluation' },
      { name: 'Dermatologist', reason: 'For skin and hormonal-related breakouts' },
      { name: 'General Physician', reason: 'For preliminary checkups and routine lab work' },
    ],
  },
  orthopedic: {
    title: 'Orthopedic Doctor',
    badge: 'Recommended Specialist',
    description: 'Treats bones, joints, muscles, ligaments, and spinal conditions.',
    avatar: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&q=80&w=260',
    whyThisDoctor: 'Recommended for knee pain, mobility issues, stiffness, and joint soreness.',
    otherSpecialists: [
      { name: 'Physiotherapist', reason: 'For muscle strengthening and rehabilitation therapy' },
      { name: 'Rheumatologist', reason: 'For autoimmune joint inflammation' },
      { name: 'General Physician', reason: 'For general acute pain management and pain relief' },
    ],
  },
  dermatologist: {
    title: 'Dermatologist',
    badge: 'Recommended Specialist',
    description: 'Specializes in skin, hair, nails, and allergy-related conditions.',
    avatar: 'https://images.unsplash.com/photo-1594824813588-e9c578052060?auto=format&fit=crop&q=80&w=260',
    whyThisDoctor: 'Ideal for acne breakouts, skin inflammation, rashes, or scalp concerns.',
    otherSpecialists: [
      { name: 'Endocrinologist', reason: 'For hormonal root causes of skin issues' },
      { name: 'Allergist / Immunologist', reason: 'For chronic allergic responses' },
      { name: 'General Physician', reason: 'For systemic infection review' },
    ],
  },
  psychiatrist: {
    title: 'Psychiatrist',
    badge: 'Recommended Specialist',
    description: 'Specializes in emotional well-being, mood concerns, stress, and mental health.',
    avatar: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?auto=format&fit=crop&q=80&w=260',
    whyThisDoctor: 'Recommended for anxiety, sleep disturbances, fatigue, and mood distress.',
    otherSpecialists: [
      { name: 'Clinical Psychologist', reason: 'For talk therapy and behavioral counseling' },
      { name: 'Neurologist', reason: 'For persistent headaches and neurological evaluation' },
      { name: 'General Physician', reason: 'For thyroid, vitamin deficiencies and overall wellness' },
    ],
  },
  general_physician: {
    title: 'General Physician',
    badge: 'Recommended Primary Care',
    description: 'For initial consultation, primary diagnosis, viral infections, and routine healthcare.',
    avatar: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?auto=format&fit=crop&q=80&w=260',
    whyThisDoctor: 'Best initial guide to assess your condition, prescribe initial care, or refer onwards.',
    otherSpecialists: [
      { name: 'ENT Specialist', reason: 'For persistent ear, nose, or throat symptoms' },
      { name: 'Gastroenterologist', reason: 'If stomach pain or digestive issues persist' },
      { name: 'Pulmonologist', reason: 'For lingering cough or respiratory evaluation' },
    ],
  },
}

export function determineSpecialist(selectedSymptomIds = []) {
  const hasUrgent = selectedSymptomIds.some(id => RED_FLAG_SYMPTOMS.includes(id))
  if (hasUrgent) {
    return {
      isUrgent: true,
      specialistKey: 'emergency',
      ...SPECIALIST_MAPPINGS.general_physician,
    }
  }

  if (
    selectedSymptomIds.includes('menstrual') ||
    selectedSymptomIds.includes('pregnancy')
  ) {
    return {
      isUrgent: false,
      specialistKey: 'gynecologist',
      ...SPECIALIST_MAPPINGS.gynecologist,
    }
  }

  if (
    selectedSymptomIds.includes('knee_pain') ||
    selectedSymptomIds.includes('joint_stiffness') ||
    selectedSymptomIds.includes('back_joint_pain') ||
    selectedSymptomIds.includes('difficulty_walking')
  ) {
    return {
      isUrgent: false,
      specialistKey: 'orthopedic',
      ...SPECIALIST_MAPPINGS.orthopedic,
    }
  }

  if (selectedSymptomIds.includes('acne_skin')) {
    return {
      isUrgent: false,
      specialistKey: 'dermatologist',
      ...SPECIALIST_MAPPINGS.dermatologist,
    }
  }

  if (selectedSymptomIds.includes('mental_health')) {
    return {
      isUrgent: false,
      specialistKey: 'psychiatrist',
      ...SPECIALIST_MAPPINGS.psychiatrist,
    }
  }

  return {
    isUrgent: false,
    specialistKey: 'general_physician',
    ...SPECIALIST_MAPPINGS.general_physician,
  }
}

// 8 Verified Doctors in Pune across Gynecologist, Orthopedic doctor, Dermatologist, General Physician
export const DOCTORS = [
  // 1. Dr. Ananya Sharma (Gynecologist)
  {
    id: 'doc-1',
    name: 'Dr. Ananya Sharma',
    initials: 'AS',
    specialty: 'Gynecologist',
    specialistKey: 'gynecologist',
    rating: 4.8,
    reviewCount: 320,
    yearsOfExperience: 8,
    experience: '8 years experience',
    hospital: 'Sahyadri Hospital, Wagholi, Pune',
    clinicType: 'Hospital',
    distance: 2.5,
    distanceText: '2.5 km',
    fee: 700,
    gender: 'Female',
    availability: 'Today',
    image: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&q=80&w=260',
    about: 'Specializes in menstrual health, PCOS, pregnancy care, fertility and women’s health. Friendly consultation with minimal waiting time.',
    qualifications: 'MBBS, MS - Obstetrics & Gynaecology (KEM Hospital)',
    languages: 'English, Hindi, Marathi',
    timings: 'Mon - Sat: 10:00 AM - 07:00 PM',
    schedule: [
      { dateLabel: 'Today, 31 Oct', key: 'today', slots: ['10:00 AM', '11:00 AM', '12:00 PM', '04:00 PM', '05:00 PM', '06:00 PM'] },
      { dateLabel: 'Sun, 1 Nov', key: 'day-1', slots: ['10:30 AM', '11:30 AM', '02:00 PM', '04:30 PM'] },
      { dateLabel: 'Mon, 2 Nov', key: 'day-2', slots: ['10:00 AM', '12:30 PM', '03:00 PM', '05:30 PM', '06:30 PM'] },
      { dateLabel: 'Tue, 3 Nov', key: 'day-3', slots: ['11:00 AM', '01:00 PM', '04:00 PM', '06:00 PM'] },
    ],
    reviews: [
      { author: 'Ritu P.', date: '2 days ago', rating: 5, comment: 'Dr. Ananya took ample time to listen to my symptoms and explained everything politely in simple Marathi.', verified: true },
      { author: 'Pooja K.', date: '1 week ago', rating: 5, comment: 'Clean hospital environment and very empathetic consultation for PCOS treatment.', verified: true },
      { author: 'Sneha M.', date: '2 weeks ago', rating: 4.5, comment: 'Great doctor with short waiting time. Prescriptions were clear and budget-friendly.', verified: true },
    ],
    badges: ['Best Match', 'Top Rated'],
  },

  // 2. Dr. Rhea Mehta (Gynecologist)
  {
    id: 'doc-2',
    name: 'Dr. Rhea Mehta',
    initials: 'RM',
    specialty: 'Gynecologist',
    specialistKey: 'gynecologist',
    rating: 4.6,
    reviewCount: 210,
    yearsOfExperience: 12,
    experience: '12 years experience',
    hospital: 'Care Life Clinic, Wagholi, Pune',
    clinicType: 'Clinic',
    distance: 3.1,
    distanceText: '3.1 km',
    fee: 600,
    gender: 'Female',
    availability: 'Tomorrow',
    image: 'https://images.unsplash.com/photo-1594824813588-e9c578052060?auto=format&fit=crop&q=80&w=260',
    about: 'Experienced gynecologist dedicated to adolescent reproductive care, preconception guidance, and routine checkups.',
    qualifications: 'MBBS, DGO (Pune University)',
    languages: 'English, Hindi, Marathi',
    timings: 'Mon - Fri: 11:00 AM - 06:00 PM',
    schedule: [
      { dateLabel: 'Today, 31 Oct', key: 'today', slots: ['02:00 PM', '03:30 PM', '05:00 PM', '06:00 PM'] },
      { dateLabel: 'Sun, 1 Nov', key: 'day-1', slots: ['11:30 AM', '01:00 PM', '03:30 PM', '05:30 PM'] },
      { dateLabel: 'Mon, 2 Nov', key: 'day-2', slots: ['10:30 AM', '12:00 PM', '02:30 PM', '04:30 PM'] },
      { dateLabel: 'Tue, 3 Nov', key: 'day-3', slots: ['11:00 AM', '02:00 PM', '04:00 PM', '05:30 PM'] },
    ],
    reviews: [
      { author: 'Meera S.', date: '3 days ago', rating: 5, comment: 'Compassionate and straightforward doctor. Clinic fees are very transparent.', verified: true },
      { author: 'Kavita D.', date: '10 days ago', rating: 4, comment: 'Helpful advice for menstrual irregularities. Staff was polite.', verified: true },
      { author: 'Swati J.', date: '3 weeks ago', rating: 5, comment: 'Dr. Rhea explained the test results thoroughly without pushing unnecessary medicines.', verified: true },
    ],
    badges: ['Closest'],
  },

  // 3. Dr. Rajesh Patil (Orthopedic doctor)
  {
    id: 'doc-3',
    name: 'Dr. Rajesh Patil',
    initials: 'RP',
    specialty: 'Orthopedic Doctor',
    specialistKey: 'orthopedic',
    rating: 4.9,
    reviewCount: 410,
    yearsOfExperience: 15,
    experience: '15 years experience',
    hospital: 'Wagholi Ortho & Trauma Care, Pune',
    clinicType: 'Clinic',
    distance: 1.8,
    distanceText: '1.8 km',
    fee: 650,
    gender: 'Male',
    availability: 'Today',
    image: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&q=80&w=260',
    about: 'Expert in joint preservation, arthritis care, sports injuries, and conservative knee pain treatment.',
    qualifications: 'MBBS, MS - Orthopaedics (Sancheti Hospital, Pune)',
    languages: 'English, Hindi, Marathi',
    timings: 'Mon - Sat: 09:00 AM - 08:00 PM',
    schedule: [
      { dateLabel: 'Today, 31 Oct', key: 'today', slots: ['10:30 AM', '12:00 PM', '04:30 PM', '06:00 PM', '07:30 PM'] },
      { dateLabel: 'Sun, 1 Nov', key: 'day-1', slots: ['10:00 AM', '11:30 AM', '01:00 PM', '05:00 PM'] },
      { dateLabel: 'Mon, 2 Nov', key: 'day-2', slots: ['09:30 AM', '11:00 AM', '03:00 PM', '05:30 PM', '07:00 PM'] },
      { dateLabel: 'Tue, 3 Nov', key: 'day-3', slots: ['10:00 AM', '12:30 PM', '04:00 PM', '06:30 PM'] },
    ],
    reviews: [
      { author: 'Gopal R.', date: 'Yesterday', rating: 5, comment: 'My knee stiffness reduced dramatically with his recommended exercises. No surgery needed!', verified: true },
      { author: 'Sunil T.', date: '5 days ago', rating: 5, comment: 'Very experienced senior orthopedic doctor. Honest assessment and clear advice.', verified: true },
      { author: 'Anita V.', date: '2 weeks ago', rating: 4.5, comment: 'Clean clinic in Wagholi. Minimal wait time if you book the morning slot.', verified: true },
    ],
    badges: ['Best Match', 'Closest'],
  },

  // 4. Dr. Sunita Deshmukh (Orthopedic doctor)
  {
    id: 'doc-4',
    name: 'Dr. Sunita Deshmukh',
    initials: 'SD',
    specialty: 'Orthopedic Doctor',
    specialistKey: 'orthopedic',
    rating: 4.7,
    reviewCount: 280,
    yearsOfExperience: 11,
    experience: '11 years experience',
    hospital: 'Ruby Hall Clinic, Pune',
    clinicType: 'Hospital',
    distance: 4.2,
    distanceText: '4.2 km',
    fee: 900,
    gender: 'Female',
    availability: 'Tomorrow',
    image: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&q=80&w=260',
    about: 'Specialist in bone density, spine care, and elderly joint mobility restoration.',
    qualifications: 'MBBS, D.Ortho, DNB - Orthopedics',
    languages: 'English, Marathi, Hindi',
    timings: 'Tue - Sun: 11:00 AM - 05:00 PM',
    schedule: [
      { dateLabel: 'Today, 31 Oct', key: 'today', slots: ['01:30 PM', '03:00 PM', '04:30 PM', '06:00 PM'] },
      { dateLabel: 'Sun, 1 Nov', key: 'day-1', slots: ['11:00 AM', '12:30 PM', '02:30 PM', '04:00 PM'] },
      { dateLabel: 'Mon, 2 Nov', key: 'day-2', slots: ['11:30 AM', '01:00 PM', '03:30 PM', '05:00 PM'] },
      { dateLabel: 'Tue, 3 Nov', key: 'day-3', slots: ['10:30 AM', '12:00 PM', '02:00 PM', '04:30 PM'] },
    ],
    reviews: [
      { author: 'Manohar P.', date: '4 days ago', rating: 5, comment: 'Dr. Sunita explained spine alignment and physiotherapy steps very clearly.', verified: true },
      { author: 'Rekha B.', date: '1 week ago', rating: 4.5, comment: 'High quality hospital care. Good guidance for joint pain.', verified: true },
      { author: 'Vikas N.', date: '3 weeks ago', rating: 4.5, comment: 'Very professional doctor with comprehensive diagnostics.', verified: true },
    ],
    badges: ['Top Rated'],
  },

  // 5. Dr. Neha Joshi (Dermatologist)
  {
    id: 'doc-5',
    name: 'Dr. Neha Joshi',
    initials: 'NJ',
    specialty: 'Dermatologist',
    specialistKey: 'dermatologist',
    rating: 4.7,
    reviewCount: 195,
    yearsOfExperience: 9,
    experience: '9 years experience',
    hospital: 'Glow Skin & Laser Clinic, Wagholi',
    clinicType: 'Clinic',
    distance: 2.0,
    distanceText: '2.0 km',
    fee: 750,
    gender: 'Female',
    availability: 'Today',
    image: 'https://images.unsplash.com/photo-1594824813588-e9c578052060?auto=format&fit=crop&q=80&w=260',
    about: 'Dedicated to clinical dermatology, acne scarring, eczema, and personalized skincare.',
    qualifications: 'MBBS, MD - Dermatology & Venereology (BJMC Pune)',
    languages: 'English, Marathi, Hindi',
    timings: 'Mon - Sat: 11:00 AM - 07:00 PM',
    schedule: [
      { dateLabel: 'Today, 31 Oct', key: 'today', slots: ['11:30 AM', '12:45 PM', '03:15 PM', '05:45 PM', '06:30 PM'] },
      { dateLabel: 'Sun, 1 Nov', key: 'day-1', slots: ['11:00 AM', '01:00 PM', '03:30 PM', '05:00 PM'] },
      { dateLabel: 'Mon, 2 Nov', key: 'day-2', slots: ['10:30 AM', '12:00 PM', '02:30 PM', '06:00 PM'] },
      { dateLabel: 'Tue, 3 Nov', key: 'day-3', slots: ['11:30 AM', '01:30 PM', '04:00 PM', '06:30 PM'] },
    ],
    reviews: [
      { author: 'Aishwarya K.', date: '3 days ago', rating: 5, comment: 'My acne cleared significantly in 3 weeks with her gentle treatment routine.', verified: true },
      { author: 'Siddharth M.', date: '10 days ago', rating: 4.5, comment: 'No unnecessary costly procedures pushed. Genuine medical skin advice.', verified: true },
      { author: 'Kalyani G.', date: '3 weeks ago', rating: 4.5, comment: 'Very pleasant clinic atmosphere in Wagholi with on-time consultations.', verified: true },
    ],
    badges: ['Best Match'],
  },

  // 6. Dr. Rohan Kulkarni (Dermatologist)
  {
    id: 'doc-6',
    name: 'Dr. Rohan Kulkarni',
    initials: 'RK',
    specialty: 'Dermatologist',
    specialistKey: 'dermatologist',
    rating: 4.8,
    reviewCount: 230,
    yearsOfExperience: 14,
    experience: '14 years experience',
    hospital: 'Jehangir Hospital, Pune',
    clinicType: 'Hospital',
    distance: 3.8,
    distanceText: '3.8 km',
    fee: 850,
    gender: 'Male',
    availability: 'Tomorrow',
    image: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?auto=format&fit=crop&q=80&w=260',
    about: 'Specializes in allergy testing, hair fall therapy, chronic psoriasis, and dermatological surgery.',
    qualifications: 'MBBS, DVD, MD - Dermatology',
    languages: 'English, Hindi, Marathi',
    timings: 'Mon - Fri: 10:00 AM - 05:00 PM',
    schedule: [
      { dateLabel: 'Today, 31 Oct', key: 'today', slots: ['02:00 PM', '03:15 PM', '04:30 PM', '05:30 PM'] },
      { dateLabel: 'Sun, 1 Nov', key: 'day-1', slots: ['10:00 AM', '11:30 AM', '02:00 PM', '04:00 PM'] },
      { dateLabel: 'Mon, 2 Nov', key: 'day-2', slots: ['10:30 AM', '12:00 PM', '02:30 PM', '04:30 PM', '05:45 PM'] },
      { dateLabel: 'Tue, 3 Nov', key: 'day-3', slots: ['10:00 AM', '01:00 PM', '03:30 PM', '05:00 PM'] },
    ],
    reviews: [
      { author: 'Nitin J.', date: '5 days ago', rating: 5, comment: 'Accurate identification of my seasonal skin allergy. Very knowledgeable doctor.', verified: true },
      { author: 'Pooja T.', date: '12 days ago', rating: 5, comment: 'Dr. Rohan is courteous and spends time explaining the cause of skin flare-ups.', verified: true },
      { author: 'Amit B.', date: '1 month ago', rating: 4.5, comment: 'Great hospital facilities and polite nursing staff at Jehangir.', verified: true },
    ],
    badges: ['Top Rated'],
  },

  // 7. Dr. Amit Verma (General Physician)
  {
    id: 'doc-7',
    name: 'Dr. Amit Verma',
    initials: 'AV',
    specialty: 'General Physician',
    specialistKey: 'general_physician',
    rating: 4.8,
    reviewCount: 520,
    yearsOfExperience: 14,
    experience: '14 years experience',
    hospital: 'City Health Family Clinic, Wagholi',
    clinicType: 'Clinic',
    distance: 1.2,
    distanceText: '1.2 km',
    fee: 400,
    gender: 'Male',
    availability: 'Today',
    image: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?auto=format&fit=crop&q=80&w=260',
    about: 'Primary care practitioner handling fevers, viral infections, diabetes checks, and family healthcare.',
    qualifications: 'MBBS, MD - General Medicine',
    languages: 'Hindi, Marathi, English',
    timings: 'Mon - Sun: 08:30 AM - 09:00 PM',
    schedule: [
      { dateLabel: 'Today, 31 Oct', key: 'today', slots: ['09:00 AM', '11:00 AM', '01:00 PM', '05:00 PM', '07:30 PM'] },
      { dateLabel: 'Sun, 1 Nov', key: 'day-1', slots: ['09:30 AM', '11:30 AM', '04:00 PM', '06:00 PM'] },
      { dateLabel: 'Mon, 2 Nov', key: 'day-2', slots: ['09:00 AM', '12:00 PM', '03:00 PM', '05:30 PM', '08:00 PM'] },
      { dateLabel: 'Tue, 3 Nov', key: 'day-3', slots: ['10:00 AM', '01:30 PM', '05:00 PM', '07:00 PM'] },
    ],
    reviews: [
      { author: 'Sachin D.', date: 'Yesterday', rating: 5, comment: 'Very affordable fee (Rs 400) and Dr. Amit gave recovery advice that worked in 2 days.', verified: true },
      { author: 'Chhaya K.', date: '4 days ago', rating: 5, comment: 'Family doctor for all our seasonal viral fevers. Highly recommended for Wagholi residents.', verified: true },
      { author: 'Rahul M.', date: '2 weeks ago', rating: 4.5, comment: 'Quick diagnosis, patient listening, and affordable generic medicine suggestions.', verified: true },
    ],
    badges: ['Best Match', 'Lowest Fee', 'Closest'],
  },

  // 8. Dr. Priya Kulkarni (General Physician)
  {
    id: 'doc-8',
    name: 'Dr. Priya Kulkarni',
    initials: 'PK',
    specialty: 'General Physician',
    specialistKey: 'general_physician',
    rating: 4.5,
    reviewCount: 180,
    yearsOfExperience: 10,
    experience: '10 years experience',
    hospital: 'Shree Clinic, Wagholi, Pune',
    clinicType: 'Clinic',
    distance: 2.9,
    distanceText: '2.9 km',
    fee: 500,
    gender: 'Female',
    availability: 'This Week',
    image: 'https://images.unsplash.com/photo-1527613426441-4da17471b66d?auto=format&fit=crop&q=80&w=260',
    about: 'Affordable, community-focused family clinic offering preventative checkups, fever management, and lifestyle guidance.',
    qualifications: 'MBBS, DNB - Family Medicine',
    languages: 'Marathi, Hindi, English',
    timings: 'Mon - Sat: 09:00 AM - 02:00 PM',
    schedule: [
      { dateLabel: 'Today, 31 Oct', key: 'today', slots: ['09:30 AM', '10:30 AM', '11:45 AM', '01:15 PM'] },
      { dateLabel: 'Sun, 1 Nov', key: 'day-1', slots: ['10:00 AM', '11:30 AM', '12:30 PM', '01:30 PM'] },
      { dateLabel: 'Mon, 2 Nov', key: 'day-2', slots: ['09:30 AM', '11:00 AM', '12:15 PM', '01:30 PM'] },
      { dateLabel: 'Tue, 3 Nov', key: 'day-3', slots: ['10:00 AM', '11:15 AM', '12:45 PM', '01:45 PM'] },
    ],
    reviews: [
      { author: 'Tanvi J.', date: '3 days ago', rating: 4.5, comment: 'Dr. Priya is very gentle with her consultation and explains symptoms in Marathi.', verified: true },
      { author: 'Dattatray S.', date: '1 week ago', rating: 4.5, comment: 'Affordable local clinic. Good attention given to senior citizen patients.', verified: true },
      { author: 'Archana P.', date: '2 weeks ago', rating: 4.5, comment: 'Very reassuring guidance for my cough and fever.', verified: true },
    ],
    badges: ['Lowest Fee'],
  },
]

export const LANGUAGES = [
  { code: 'en', name: 'English', native: 'English', flag: '🇬🇧' },
  { code: 'hi', name: 'Hindi', native: 'हिंदी', flag: '🇮🇳' },
  { code: 'mr', name: 'Marathi', native: 'मराठी', flag: '🇮🇳' },
  { code: 'ta', name: 'Tamil', native: 'தமிழ்', flag: '🇮🇳' },
  { code: 'te', name: 'Telugu', native: 'తెలుగు', flag: '🇮🇳' },
  { code: 'bn', name: 'Bengali', native: 'বাংলা', flag: '🇮🇳' },
  { code: 'kn', name: 'Kannada', native: 'ಕನ್ನಡ', flag: '🇮🇳' },
]

export const ONBOARDING_SLIDES = [
  {
    title: 'Better Healthcare for Everyone',
    subtitle: 'Find the right doctor, easily. Affordable. Reliable. Nearby.',
    bullets: [
      { text: 'Symptom-based doctor guidance', icon: 'Sparkles', color: '#137A6E' },
      { text: 'Trusted & affordable options', icon: 'ShieldCheck', color: '#1A8A7D' },
      { text: 'Easy appointment booking', icon: 'CalendarCheck', color: '#137A6E' },
      { text: 'Emergency ambulance support', icon: 'AlertCircle', color: '#C73E1D' },
    ],
  },
  {
    title: 'Guidance Without Confusion',
    subtitle: 'Never guess which specialist to see. We guide you using plain everyday words.',
    bullets: [
      { text: 'Select familiar symptoms', icon: 'CheckCircle2', color: '#137A6E' },
      { text: 'Instant specialty recommendation', icon: 'Sparkles', color: '#1A8A7D' },
      { text: 'Guidance only — never disease predictions', icon: 'ShieldAlert', color: '#0F3D3E' },
      { text: 'Red-flag detection for urgent cases', icon: 'Flame', color: '#C73E1D' },
    ],
  },
  {
    title: 'Transparent & Local Care',
    subtitle: 'Compare transparent consultation fees and confirmed clinic slots near you.',
    bullets: [
      { text: 'Verified clinic and hospital fees', icon: 'Coins', color: '#137A6E' },
      { text: 'Walk-in or reserved time slots', icon: 'Clock', color: '#1A8A7D' },
      { text: 'Ratings from completed patient visits', icon: 'Star', color: '#137A6E' },
      { text: 'Available in your preferred regional language', icon: 'Globe', color: '#0F3D3E' },
    ],
  },
]
