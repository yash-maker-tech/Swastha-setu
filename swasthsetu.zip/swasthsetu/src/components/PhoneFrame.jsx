import React from 'react'
import { Wifi, Battery, Signal } from 'lucide-react'

export default function PhoneFrame({ children }) {
  return (
    <div className="min-h-screen w-full flex items-center justify-center p-0 md:p-6 bg-[#EBEAE5]">
      {/* Mobile container / Desktop phone frame */}
      <div className="relative w-full md:w-[390px] h-screen md:h-[844px] max-h-screen md:max-h-[844px] bg-[#F7F5EF] md:rounded-[44px] shadow-none md:shadow-[0_25px_60px_-15px_rgba(15,61,62,0.3),0_0_0_10px_#1E2A2B] overflow-hidden flex flex-col border border-transparent md:border-[#384849]">
        
        {/* Phone Speaker & Camera Notch (Desktop view) */}
        <div className="hidden md:flex absolute top-0 left-1/2 -translate-x-1/2 w-36 h-6 bg-[#1E2A2B] rounded-b-2xl z-50 items-center justify-center gap-3">
          <div className="w-12 h-1 bg-[#3A4A4B] rounded-full"></div>
          <div className="w-3 h-3 bg-[#111A1B] rounded-full border border-[#2B3B3D]"></div>
        </div>

        {/* Mobile Status Bar */}
        <div className="w-full h-11 px-6 pt-2 pb-1 flex items-center justify-between text-[#17302F] text-xs font-semibold z-40 select-none bg-transparent">
          <span>9:41</span>
          <div className="flex items-center gap-1.5 opacity-80">
            <Signal className="w-3.5 h-3.5" strokeWidth={2.2} />
            <Wifi className="w-3.5 h-3.5" strokeWidth={2.2} />
            <Battery className="w-4 h-4" strokeWidth={2.2} />
          </div>
        </div>

        {/* Main Content Area with smooth scrolling */}
        <div className="flex-1 overflow-y-auto overflow-x-hidden relative flex flex-col">
          {children}
        </div>

        {/* iOS Home Indicator Bar */}
        <div className="w-full py-1.5 flex justify-center bg-transparent shrink-0">
          <div className="w-32 h-1 bg-[#17302F]/20 rounded-full"></div>
        </div>
      </div>
    </div>
  )
}
