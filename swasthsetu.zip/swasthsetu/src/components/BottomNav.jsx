import React from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import { Home, CalendarCheck, AlertTriangle, User } from 'lucide-react'
import { useApp } from '../context/AppContext'
import { t } from '../i18n'

export default function BottomNav() {
  const navigate = useNavigate()
  const location = useLocation()
  const { appointments, language } = useApp()
  const pathname = location.pathname

  const activeAppointmentsCount = appointments.filter(a => a.status === 'Confirmed').length

  const tabs = [
    {
      id: 'home',
      label: t('tabHome', language),
      path: '/home',
      icon: Home,
    },
    {
      id: 'appointments',
      label: t('tabAppointments', language),
      path: '/appointments',
      icon: CalendarCheck,
      badge: activeAppointmentsCount > 0 ? activeAppointmentsCount : null,
    },
    {
      id: 'emergency',
      label: t('tabEmergency', language),
      path: '/emergency',
      icon: AlertTriangle,
      isEmergency: true,
    },
    {
      id: 'profile',
      label: t('tabProfile', language),
      path: '/profile',
      icon: User,
    },
  ]

  return (
    <nav className="w-full bg-white/95 backdrop-blur-md border-t border-[#D6E3DE] px-3 py-2 flex items-center justify-around shrink-0 z-30 shadow-[0_-2px_12px_rgba(15,61,62,0.05)]">
      {tabs.map((tab) => {
        const Icon = tab.icon
        const isActive = pathname === tab.path || (tab.id === 'home' && pathname === '/')

        return (
          <button
            key={tab.id}
            onClick={() => navigate(tab.path)}
            className={`flex flex-col items-center justify-center py-1 px-2 rounded-xl transition-all duration-200 relative ${
              isActive
                ? tab.isEmergency
                  ? 'text-[#C73E1D] font-bold'
                  : 'text-[#137A6E] font-bold'
                : tab.isEmergency
                ? 'text-[#C73E1D]/80 hover:text-[#C73E1D]'
                : 'text-[#52686A] hover:text-[#137A6E]'
            }`}
          >
            <div className="relative">
              <Icon
                className={`w-5 h-5 transition-transform ${
                  isActive ? 'scale-110' : 'scale-100'
                }`}
                strokeWidth={isActive ? 2.4 : 1.8}
              />
              {tab.badge && (
                <span className="absolute -top-1 -right-2 bg-[#137A6E] text-white text-[10px] w-4 h-4 rounded-full flex items-center justify-center font-bold">
                  {tab.badge}
                </span>
              )}
            </div>
            <span
              className={`text-[11px] mt-1 tracking-tight leading-tight truncate max-w-[70px] ${
                isActive ? 'font-bold' : 'font-medium'
              }`}
            >
              {tab.label}
            </span>
            {isActive && (
              <span
                className={`w-1 h-1 rounded-full mt-0.5 ${
                  tab.isEmergency ? 'bg-[#C73E1D]' : 'bg-[#137A6E]'
                }`}
              />
            )}
          </button>
        )
      })}
    </nav>
  )
}
