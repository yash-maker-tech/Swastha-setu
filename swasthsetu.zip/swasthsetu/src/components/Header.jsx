import React from 'react'
import { useNavigate } from 'react-router-dom'
import { ArrowLeft, Bell, Globe } from 'lucide-react'

export function AppLogo({ size = 'md' }) {
  const iconSizes = {
    sm: 'w-6 h-6',
    md: 'w-8 h-8',
    lg: 'w-16 h-16',
  }

  const textSizes = {
    sm: 'text-lg',
    md: 'text-xl',
    lg: 'text-3xl',
  }

  return (
    <div className="flex items-center gap-2">
      <div className={`${iconSizes[size]} relative flex items-center justify-center shrink-0`}>
        {/* Heart + Stethoscope custom SVG emblem */}
        <svg
          viewBox="0 0 48 48"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full drop-shadow-sm"
        >
          {/* Soft background glow */}
          <rect width="48" height="48" rx="14" fill="#E7F0EC" />
          
          {/* Cute Heart */}
          <path
            d="M24 16.5C22.2 13.8 17.5 13.5 15.2 16.2C13.2 18.5 13.6 22.3 16.3 24.8L24 31.8L31.7 24.8C34.4 22.3 34.8 18.5 32.8 16.2C30.5 13.5 25.8 13.8 24 16.5Z"
            fill="#6FD3BF"
            fillOpacity="0.45"
          />

          {/* Stethoscope Path */}
          <path
            d="M17 19V23C17 26.866 20.134 30 24 30C27.866 30 31 26.866 31 23V19"
            stroke="#137A6E"
            strokeWidth="2.8"
            strokeLinecap="round"
          />
          <path
            d="M24 30V35"
            stroke="#137A6E"
            strokeWidth="2.8"
            strokeLinecap="round"
          />
          <circle cx="24" cy="36.5" r="3.2" fill="#0F3D3E" stroke="#137A6E" strokeWidth="1.5" />
          {/* Ear tips */}
          <circle cx="17" cy="18" r="1.8" fill="#0F3D3E" />
          <circle cx="31" cy="18" r="1.8" fill="#0F3D3E" />
        </svg>
      </div>
      <div className="flex flex-col">
        <span className={`font-extrabold font-heading text-[#0F3D3E] tracking-tight ${textSizes[size]}`}>
          SwasthSetu
        </span>
      </div>
    </div>
  )
}

export default function Header({ title, showBack = true, backTo, rightAction }) {
  const navigate = useNavigate()

  const handleBack = () => {
    if (backTo) {
      navigate(backTo)
    } else {
      navigate(-1)
    }
  }

  return (
    <header className="w-full px-5 py-3 flex items-center justify-between bg-[#F7F5EF]/95 backdrop-blur-sm shrink-0 border-b border-[#D6E3DE]/60 z-20">
      <div className="flex items-center gap-3">
        {showBack ? (
          <button
            onClick={handleBack}
            className="w-10 h-10 rounded-full bg-white border border-[#D6E3DE] flex items-center justify-center text-[#17302F] hover:bg-[#E7F0EC] transition-colors shadow-sm active:scale-95"
            aria-label="Go back"
          >
            <ArrowLeft className="w-5 h-5 text-[#0F3D3E]" />
          </button>
        ) : (
          <AppLogo size="sm" />
        )}

        {title && (
          <h1 className="text-lg font-bold font-heading text-[#0F3D3E] truncate">
            {title}
          </h1>
        )}
      </div>

      <div className="flex items-center gap-2">
        {rightAction ? (
          rightAction
        ) : (
          <>
            <button
              onClick={() => navigate('/language')}
              className="w-9 h-9 rounded-full bg-white border border-[#D6E3DE] flex items-center justify-center text-[#52686A] hover:text-[#137A6E] hover:bg-[#E7F0EC] transition-colors shadow-sm"
              title="Change Language"
            >
              <Globe className="w-4 h-4" />
            </button>
            <button
              onClick={() => navigate('/emergency')}
              className="w-9 h-9 rounded-full bg-white border border-[#D6E3DE] flex items-center justify-center text-[#52686A] hover:text-[#C73E1D] hover:bg-[#FDECE8] transition-colors shadow-sm"
              title="Emergency"
            >
              <Bell className="w-4 h-4" />
            </button>
          </>
        )}
      </div>
    </header>
  )
}
