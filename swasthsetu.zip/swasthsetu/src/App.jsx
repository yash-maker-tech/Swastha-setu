import React from 'react'
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { AppProvider } from './context/AppContext'
import PhoneFrame from './components/PhoneFrame'

import SplashScreen from './screens/SplashScreen'
import OnboardingScreen from './screens/OnboardingScreen'
import HomeScreen from './screens/HomeScreen'
import SymptomScreen from './screens/SymptomScreen'
import SpecialistScreen from './screens/SpecialistScreen'
import FiltersScreen from './screens/FiltersScreen'
import DoctorListScreen from './screens/DoctorListScreen'
import DoctorProfileScreen from './screens/DoctorProfileScreen'
import AppointmentConfirmationScreen from './screens/AppointmentConfirmationScreen'
import ReviewScreen from './screens/ReviewScreen'
import EmergencyScreen from './screens/EmergencyScreen'
import LanguageScreen from './screens/LanguageScreen'
import AppointmentsScreen from './screens/AppointmentsScreen'
import ProfileScreen from './screens/ProfileScreen'

export default function App() {
  return (
    <AppProvider>
      <Router>
        <PhoneFrame>
          <Routes>
            {/* Screen 1: Splash */}
            <Route path="/" element={<SplashScreen />} />
            <Route path="/splash" element={<SplashScreen />} />

            {/* Screen 2: Onboarding */}
            <Route path="/onboarding" element={<OnboardingScreen />} />

            {/* Screen 3: Home */}
            <Route path="/home" element={<HomeScreen />} />

            {/* Screen 4: Symptom selection */}
            <Route path="/symptoms" element={<SymptomScreen />} />

            {/* Screen 5: Specialist suggestion */}
            <Route path="/specialist" element={<SpecialistScreen />} />

            {/* Screen 6: Filters */}
            <Route path="/filters" element={<FiltersScreen />} />

            {/* Screen 7: Doctor list */}
            <Route path="/doctors" element={<DoctorListScreen />} />

            {/* Screen 8: Doctor profile */}
            <Route path="/doctor/:id" element={<DoctorProfileScreen />} />
            <Route path="/doctor" element={<DoctorProfileScreen />} />

            {/* Screen 9: Appointment confirmation */}
            <Route path="/confirmation" element={<AppointmentConfirmationScreen />} />

            {/* Screen 10: After visit review */}
            <Route path="/review" element={<ReviewScreen />} />

            {/* Screen 11: Emergency & Ambulance */}
            <Route path="/emergency" element={<EmergencyScreen />} />
            <Route path="/ambulance" element={<EmergencyScreen />} />

            {/* Screen 12: Language support */}
            <Route path="/language" element={<LanguageScreen />} />

            {/* Bottom Nav tabs */}
            <Route path="/appointments" element={<AppointmentsScreen />} />
            <Route path="/profile" element={<ProfileScreen />} />

            {/* Fallback */}
            <Route path="*" element={<Navigate to="/home" replace />} />
          </Routes>
        </PhoneFrame>
      </Router>
    </AppProvider>
  )
}
