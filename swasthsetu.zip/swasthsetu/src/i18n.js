export const translations = {
  en: {
    // Bottom Nav
    tabHome: 'Home',
    tabAppointments: 'Appointments',
    tabEmergency: 'Emergency',
    tabProfile: 'Profile',

    // Home
    greeting: 'Hello!',
    howCanWeHelp: 'How can we help you today?',
    searchPlaceholder: 'Search symptoms (e.g. stomach pain)',
    findDoctor: 'Find a Doctor',
    symptomGuide: 'Symptom Guide',
    bookAmbulance: 'Book Ambulance',
    guidedBannerTitle: 'Not sure which doctor to visit?',
    guidedBannerSub: "Select your symptoms and we'll guide you to the right specialist.",
    startSymptomCheck: 'Start symptom check',
    popularSearches: 'Popular Searches',
    seeMore: 'See more',
    homeDisclaimer: 'SwasthSetu is a navigation tool. We never diagnose illnesses or predict disease names. We help you find the appropriate doctor for medical advice.',

    // Symptoms
    symptomTitle: 'What seems to be the issue?',
    symptomSub: 'Select one or more symptoms that describe how you feel.',
    symptomSearchPlaceholder: 'Search symptoms (e.g. knee, fever)...',
    selected: 'Selected',
    clearAll: 'Clear all',
    tapToSelect: 'Tap any tile above to select your symptoms',
    next: 'Next',
    reviewEmergency: 'Review Emergency Guidance',
    urgentNotice: 'Urgent symptom selected. We will provide immediate emergency options.',

    // Symptoms labels
    fever: 'Fever',
    stomach_pain: 'Stomach pain',
    headache: 'Headache',
    cough_cold: 'Cough & cold',
    menstrual: 'Menstrual irregularities',
    pregnancy: 'Pregnancy related',
    acne_skin: 'Acne / Skin issues',
    back_joint_pain: 'Back or joint pain',
    mental_health: 'Mental health concerns',
    knee_pain: 'Knee pain',
    joint_stiffness: 'Joint stiffness',
    difficulty_walking: 'Difficulty walking',
    chest_pain: 'Chest pain',
    difficulty_breathing: 'Difficulty breathing',
  },

  hi: {
    // Bottom Nav
    tabHome: 'होम',
    tabAppointments: 'अपॉइंटमेंट',
    tabEmergency: 'आपातकालीन',
    tabProfile: 'प्रोफाइल',

    // Home
    greeting: 'नमस्ते!',
    howCanWeHelp: 'आज हम आपकी क्या मदद कर सकते हैं?',
    searchPlaceholder: 'लक्षण खोजें (उदा. पेट दर्द)',
    findDoctor: 'डॉक्टर खोजें',
    symptomGuide: 'लक्षण गाइड',
    bookAmbulance: 'एंबुलेंस बुलाएं',
    guidedBannerTitle: 'तय नहीं कर पा रहे किस डॉक्टर के पास जाएं?',
    guidedBannerSub: 'अपने लक्षण चुनें, हम सही विशेषज्ञ तक आपका मार्गदर्शन करेंगे।',
    startSymptomCheck: 'लक्षण जांच शुरू करें',
    popularSearches: 'लोकप्रिय खोजें',
    seeMore: 'और देखें',
    homeDisclaimer: 'स्वास्थ्यसेतु एक नेविगेशन ऐप है। हम कभी बीमारियों का निदान या भविष्यवाणी नहीं करते। हम केवल सही डॉक्टर चुनने में मदद करते हैं।',

    // Symptoms
    symptomTitle: 'आपको क्या समस्या हो रही है?',
    symptomSub: 'अपनी स्थिति बताने वाले एक या अधिक लक्षण चुनें।',
    symptomSearchPlaceholder: 'लक्षण खोजें (उदा. घुटना, बुखार)...',
    selected: 'चुने गए',
    clearAll: 'सभी हटाएं',
    tapToSelect: 'लक्षण चुनने के लिए ऊपर दिए गए कार्ड पर टैप करें',
    next: 'आगे बढ़ें',
    reviewEmergency: 'आपातकालीन सलाह देखें',
    urgentNotice: 'गंभीर लक्षण चुना गया। तुरंत आपातकालीन सहायता की सलाह दी जाती है।',

    // Symptoms labels
    fever: 'बुखार',
    stomach_pain: 'पेट दर्द',
    headache: 'सिरदर्द',
    cough_cold: 'खांसी और जुकाम',
    menstrual: 'अनियमित माहवारी',
    pregnancy: 'गर्भावस्था संबंधित',
    acne_skin: 'मुंहासे / त्वचा समस्या',
    back_joint_pain: 'पीठ या जोड़ों का दर्द',
    mental_health: 'मानसिक स्वास्थ्य चिंता',
    knee_pain: 'घुटने का दर्द',
    joint_stiffness: 'जोड़ों में अकड़न',
    difficulty_walking: 'चलने में कठिनाई',
    chest_pain: 'सीने में दर्द',
    difficulty_breathing: 'सांस लेने में तकलीफ',
  },

  mr: {
    // Bottom Nav
    tabHome: 'मुख्यपृष्ठ',
    tabAppointments: 'माझ्या भेटी',
    tabEmergency: 'तातडीची मदत',
    tabProfile: 'माहिती',

    // Home
    greeting: 'नमस्कार!',
    howCanWeHelp: 'आज आम्ही तुम्हाला कशी मदत करू शकतो?',
    searchPlaceholder: 'लक्षणे शोधा (उदा. पोटदुखी)',
    findDoctor: 'डॉक्टर शोधा',
    symptomGuide: 'लक्षण मार्गदर्शक',
    bookAmbulance: 'रुग्णवाहिका बोलवा',
    guidedBannerTitle: 'कोणत्या डॉक्टरकडे जावे समजत नाही?',
    guidedBannerSub: 'आपली लक्षणे निवडा आणि आम्ही योग्य तज्ञाकडे मार्गदर्शन करू.',
    startSymptomCheck: 'लक्षण तपासणी सुरू करा',
    popularSearches: 'नेहमीचे शोध',
    seeMore: 'अधिक पहा',
    homeDisclaimer: 'स्वास्थ्यसेतू हे एक आरोग्य मार्गदर्शन साधन आहे. आम्ही आजारांचे निदान करत नाही. आम्ही आपल्याला योग्य डॉक्टरांकडे पोहोचवतो.',

    // Symptoms
    symptomTitle: 'तुम्हाला काय त्रास होत आहे?',
    symptomSub: 'तुमच्या त्रासाशी जुळणारी एक किंवा अधिक लक्षणे निवडा.',
    symptomSearchPlaceholder: 'लक्षणे शोधा (उदा. गुडघेदुखी, ताप)...',
    selected: 'निवडलेले',
    clearAll: 'सर्व काढा',
    tapToSelect: 'लक्षणे निवडण्यासाठी वरील कार्डवर टॅप करा',
    next: 'पुढे जा',
    reviewEmergency: 'तातडीची मदत पहा',
    urgentNotice: 'तातडीचे लक्षण निवडले. त्वरित आपत्कालीन संपर्क साधण्याचा सल्ला दिला जातो.',

    // Symptoms labels
    fever: 'ताप',
    stomach_pain: 'पोटदुखी',
    headache: 'डोकेदुखी',
    cough_cold: 'खोकला व सर्दी',
    menstrual: 'मासिक पाळीच्या तक्रारी',
    pregnancy: 'गर्भावस्थेशी संबंधित',
    acne_skin: 'मुरुमे / त्वचेच्या समस्या',
    back_joint_pain: 'पाठ किंवा सांधेदुखी',
    mental_health: 'मानसिक ताण / आरोग्य',
    knee_pain: 'गुडघेदुखी',
    joint_stiffness: 'सांध्यांचा ताठरपणा',
    difficulty_walking: 'चालण्यात त्रास',
    chest_pain: 'छातीत दुखणे',
    difficulty_breathing: 'श्वास घेण्यास त्रास',
  },
}

export function t(key, lang = 'en') {
  const currentLang = translations[lang] || translations.en
  return currentLang[key] || translations.en[key] || key
}
