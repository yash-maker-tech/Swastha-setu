import React, { createContext, useContext, useState, useEffect } from 'react'
import { DOCTORS } from '../data'

const AppContext = createContext(null)

const STORAGE_KEY = 'swasthsetu_state_v2'

const defaultState = {
  selectedSymptoms: [],
  filters: {
    location: 'Wagholi, Pune',
    maxBudget: 1000,
    availability: 'Today',
    gender: 'Any',
    rating: 4.0,
    clinicType: 'Any',
  },
  chosenDoctorId: 'doc-1',
  booking: null,
  appointments: [
    {
      id: 'apt-completed-1',
      doctorId: 'doc-1',
      doctorName: 'Dr. Ananya Sharma',
      specialty: 'Gynecologist',
      hospital: 'Sahyadri Hospital, Wagholi, Pune',
      date: 'Wed, 21 Oct 2026',
      time: '11:00 AM',
      fee: 700,
      status: 'Completed',
      canReview: true,
      hasReviewed: false,
    },
    {
      id: 'apt-upcoming-1',
      doctorId: 'doc-7',
      doctorName: 'Dr. Amit Verma',
      specialty: 'General Physician',
      hospital: 'City Health Family Clinic, Wagholi',
      date: 'Today, 31 Oct 2026',
      time: '05:00 PM',
      fee: 400,
      status: 'Confirmed',
      canReview: false,
      hasReviewed: false,
    }
  ],
  language: 'en',
  reviews: [],
}

export function AppProvider({ children }) {
  const [state, setState] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY)
      if (saved) {
        const parsed = JSON.parse(saved)
        return {
          ...defaultState,
          ...parsed,
          filters: { ...defaultState.filters, ...(parsed.filters || {}) },
        }
      }
    } catch (e) {
      console.warn('Could not load stored state:', e)
    }
    return defaultState
  })

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state))
    } catch (e) {
      console.warn('Could not save state to localStorage:', e)
    }
  }, [state])

  // Symptoms
  const toggleSymptom = (symptomId) => {
    setState(prev => {
      const exists = prev.selectedSymptoms.includes(symptomId)
      return {
        ...prev,
        selectedSymptoms: exists
          ? prev.selectedSymptoms.filter(id => id !== symptomId)
          : [...prev.selectedSymptoms, symptomId],
      }
    })
  }

  const removeSymptom = (symptomId) => {
    setState(prev => ({
      ...prev,
      selectedSymptoms: prev.selectedSymptoms.filter(id => id !== symptomId),
    }))
  }

  const clearSymptoms = () => {
    setState(prev => ({ ...prev, selectedSymptoms: [] }))
  }

  // Filters
  const updateFilters = (newFilters) => {
    setState(prev => ({
      ...prev,
      filters: { ...prev.filters, ...newFilters },
    }))
  }

  const resetFilters = () => {
    setState(prev => ({
      ...prev,
      filters: defaultState.filters,
    }))
  }

  // Doctor selection
  const setChosenDoctorId = (id) => {
    setState(prev => ({ ...prev, chosenDoctorId: id }))
  }

  const getChosenDoctor = () => {
    return DOCTORS.find(d => d.id === state.chosenDoctorId) || DOCTORS[0]
  }

  // Booking & Appointments
  const bookAppointment = ({ doctor, date, slot, patientName, patientPhone }) => {
    const newApt = {
      id: `apt-${Date.now()}`,
      doctorId: doctor.id,
      doctorName: doctor.name,
      specialty: doctor.specialty,
      hospital: doctor.hospital,
      date: date || 'Today, 31 Oct 2026',
      time: slot || '11:00 AM',
      fee: doctor.fee,
      patientName: patientName || 'Patient Guest',
      patientPhone: patientPhone || '+91 98765 43210',
      status: 'Confirmed',
      canReview: false,
      hasReviewed: false,
    }
    setState(prev => ({
      ...prev,
      booking: newApt,
      appointments: [newApt, ...prev.appointments],
    }))
    return newApt
  }

  const cancelAppointment = (appointmentId) => {
    setState(prev => ({
      ...prev,
      appointments: prev.appointments.map(a =>
        a.id === appointmentId ? { ...a, status: 'Cancelled' } : a
      ),
      booking: prev.booking && prev.booking.id === appointmentId
        ? { ...prev.booking, status: 'Cancelled' }
        : prev.booking,
    }))
  }

  // Language
  const setLanguage = (langCode) => {
    setState(prev => ({ ...prev, language: langCode }))
  }

  // Reviews
  const submitReview = ({ doctorId, rating, comment, tags, appointmentId }) => {
    const newRev = {
      id: `rev-${Date.now()}`,
      doctorId,
      rating,
      comment,
      tags,
      date: 'Just now',
      verified: true,
    }

    setState(prev => ({
      ...prev,
      reviews: [newRev, ...prev.reviews],
      appointments: prev.appointments.map(a =>
        a.id === appointmentId || a.doctorId === doctorId
          ? { ...a, hasReviewed: true }
          : a
      ),
    }))
  }

  return (
    <AppContext.Provider
      value={{
        selectedSymptoms: state.selectedSymptoms,
        toggleSymptom,
        removeSymptom,
        clearSymptoms,
        filters: state.filters,
        updateFilters,
        resetFilters,
        chosenDoctorId: state.chosenDoctorId,
        setChosenDoctorId,
        chosenDoctor: getChosenDoctor(),
        booking: state.booking,
        appointments: state.appointments,
        bookAppointment,
        cancelAppointment,
        language: state.language,
        setLanguage,
        reviews: state.reviews,
        submitReview,
      }}
    >
      {children}
    </AppContext.Provider>
  )
}

export function useApp() {
  const context = useContext(AppContext)
  if (!context) {
    throw new Error('useApp must be used within an AppProvider')
  }
  return context
}
