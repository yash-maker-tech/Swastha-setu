import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  MapPin,
  LocateFixed,
  IndianRupee,
  Calendar,
  User,
  Star,
  Building2,
  ArrowRight,
  RotateCcw,
} from 'lucide-react'
import Header from '../components/Header'
import { useApp } from '../context/AppContext'

export default function FiltersScreen() {
  const navigate = useNavigate()
  const { filters, updateFilters, resetFilters } = useApp()

  const [localFilters, setLocalFilters] = useState(filters)

  const handleApply = () => {
    updateFilters(localFilters)
    navigate('/doctors')
  }

  const handleReset = () => {
    resetFilters()
    setLocalFilters({
      location: 'Wagholi, Pune',
      maxBudget: 1000,
      availability: 'Today',
      gender: 'Any',
      rating: 4.0,
      clinicType: 'Any',
    })
  }

  return (
    <div className="flex-1 flex flex-col justify-between bg-[#F7F5EF] select-none">
      {/* Top Header */}
      <Header
        title="Filter Your Preferences"
        backTo="/specialist"
        rightAction={
          <button
            onClick={handleReset}
            className="text-xs font-bold text-[#52686A] hover:text-[#137A6E] flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-black/5"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset</span>
          </button>
        }
      />

      {/* Main Filter Scrollable Body */}
      <div className="flex-1 overflow-y-auto px-5 py-4 space-y-5">
        
        {/* Step Indicator */}
        <div className="flex items-center gap-1.5 justify-center py-1">
          <span className="w-8 h-1.5 rounded-full bg-[#137A6E]"></span>
          <span className="w-8 h-1.5 rounded-full bg-[#137A6E]"></span>
          <span className="w-8 h-1.5 rounded-full bg-[#137A6E]"></span>
        </div>

        {/* 1. Location Section */}
        <div className="bg-white border border-[#D6E3DE] rounded-2xl p-4 shadow-sm space-y-2">
          <label className="text-xs font-bold text-[#0F3D3E] flex items-center gap-1.5">
            <MapPin className="w-4 h-4 text-[#137A6E]" />
            <span>Your Location</span>
          </label>
          <div className="relative">
            <input
              type="text"
              value={localFilters.location}
              onChange={(e) =>
                setLocalFilters(prev => ({ ...prev, location: e.target.value }))
              }
              placeholder="Enter locality or area"
              className="w-full bg-[#F7F5EF] border border-[#D6E3DE] rounded-xl py-2.5 pl-3.5 pr-10 text-xs font-semibold text-[#17302F] focus:outline-none focus:border-[#137A6E]"
            />
            <button
              onClick={() =>
                setLocalFilters(prev => ({ ...prev, location: 'Wagholi, Pune' }))
              }
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#137A6E] hover:opacity-80 p-1"
              title="Detect current location"
            >
              <LocateFixed className="w-4 h-4" />
            </button>
          </div>
          <span className="text-[11px] text-[#52686A] block">
            Showing doctors within 5-10 km radius.
          </span>
        </div>

        {/* 2. Budget Range (Consultation Fee) */}
        <div className="bg-white border border-[#D6E3DE] rounded-2xl p-4 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-[#0F3D3E] flex items-center gap-1.5">
              <IndianRupee className="w-4 h-4 text-[#137A6E]" />
              <span>Budget Range (Consultation Fee)</span>
            </label>
            <span className="text-xs font-extrabold text-[#137A6E] bg-[#E7F0EC] px-2.5 py-0.5 rounded-full">
              Up to ₹{localFilters.maxBudget}
            </span>
          </div>

          <input
            type="range"
            min="200"
            max="2000"
            step="50"
            value={localFilters.maxBudget}
            onChange={(e) =>
              setLocalFilters(prev => ({
                ...prev,
                maxBudget: Number(e.target.value),
              }))
            }
            className="w-full accent-[#137A6E] h-2 bg-[#D6E3DE] rounded-lg cursor-pointer"
          />

          <div className="flex justify-between text-[11px] text-[#52686A] font-semibold">
            <span>₹200 (Affordable)</span>
            <span>₹1000</span>
            <span>₹2000 (Max)</span>
          </div>
        </div>

        {/* 3. Availability Chips */}
        <div className="bg-white border border-[#D6E3DE] rounded-2xl p-4 shadow-sm space-y-2.5">
          <label className="text-xs font-bold text-[#0F3D3E] flex items-center gap-1.5">
            <Calendar className="w-4 h-4 text-[#137A6E]" />
            <span>Availability</span>
          </label>
          <div className="flex items-center gap-2">
            {['Today', 'Tomorrow', 'This Week'].map((item) => {
              const active = localFilters.availability === item
              return (
                <button
                  key={item}
                  onClick={() =>
                    setLocalFilters(prev => ({ ...prev, availability: item }))
                  }
                  className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all ${
                    active
                      ? 'bg-[#137A6E] text-white shadow-sm'
                      : 'bg-[#E7F0EC] text-[#52686A] hover:bg-[#D6E3DE]'
                  }`}
                >
                  {item}
                </button>
              )
            })}
          </div>
        </div>

        {/* 4. Gender Preference Chips */}
        <div className="bg-white border border-[#D6E3DE] rounded-2xl p-4 shadow-sm space-y-2.5">
          <label className="text-xs font-bold text-[#0F3D3E] flex items-center gap-1.5">
            <User className="w-4 h-4 text-[#137A6E]" />
            <span>Gender Preference</span>
          </label>
          <div className="flex items-center gap-2">
            {['Any', 'Female', 'Male'].map((item) => {
              const active = localFilters.gender === item
              return (
                <button
                  key={item}
                  onClick={() =>
                    setLocalFilters(prev => ({ ...prev, gender: item }))
                  }
                  className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all ${
                    active
                      ? 'bg-[#137A6E] text-white shadow-sm'
                      : 'bg-[#E7F0EC] text-[#52686A] hover:bg-[#D6E3DE]'
                  }`}
                >
                  {item}
                </button>
              )
            })}
          </div>
        </div>

        {/* 5. Ratings Chips */}
        <div className="bg-white border border-[#D6E3DE] rounded-2xl p-4 shadow-sm space-y-2.5">
          <label className="text-xs font-bold text-[#0F3D3E] flex items-center gap-1.5">
            <Star className="w-4 h-4 text-[#137A6E]" />
            <span>Ratings</span>
          </label>
          <div className="flex items-center gap-2">
            {[
              { label: '4.0 & above', val: 4.0 },
              { label: '3.5 & above', val: 3.5 },
              { label: 'Any', val: 0 },
            ].map((item) => {
              const active = localFilters.rating === item.val
              return (
                <button
                  key={item.label}
                  onClick={() =>
                    setLocalFilters(prev => ({ ...prev, rating: item.val }))
                  }
                  className={`flex-1 py-2 px-2.5 rounded-xl text-xs font-bold transition-all text-center ${
                    active
                      ? 'bg-[#137A6E] text-white shadow-sm'
                      : 'bg-[#E7F0EC] text-[#52686A] hover:bg-[#D6E3DE]'
                  }`}
                >
                  {item.label}
                </button>
              )
            })}
          </div>
        </div>

        {/* 6. Hospital/Clinic Type Chips */}
        <div className="bg-white border border-[#D6E3DE] rounded-2xl p-4 shadow-sm space-y-2.5">
          <label className="text-xs font-bold text-[#0F3D3E] flex items-center gap-1.5">
            <Building2 className="w-4 h-4 text-[#137A6E]" />
            <span>Hospital / Clinic Type (Optional)</span>
          </label>
          <div className="flex items-center gap-2">
            {['Any', 'Hospital', 'Clinic'].map((item) => {
              const active = localFilters.clinicType === item
              return (
                <button
                  key={item}
                  onClick={() =>
                    setLocalFilters(prev => ({ ...prev, clinicType: item }))
                  }
                  className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all ${
                    active
                      ? 'bg-[#137A6E] text-white shadow-sm'
                      : 'bg-[#E7F0EC] text-[#52686A] hover:bg-[#D6E3DE]'
                  }`}
                >
                  {item}
                </button>
              )
            })}
          </div>
        </div>

      </div>

      {/* Sticky Bottom Show Doctors Button */}
      <div className="bg-white border-t border-[#D6E3DE] p-4 shadow-lg shrink-0">
        <button
          onClick={handleApply}
          className="tap-target w-full bg-[#137A6E] hover:bg-[#0F3D3E] active:scale-[0.98] text-white font-bold text-base rounded-xl flex items-center justify-center gap-2 shadow-md transition-all duration-200"
        >
          <span>Show Doctors</span>
          <ArrowRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  )
}
