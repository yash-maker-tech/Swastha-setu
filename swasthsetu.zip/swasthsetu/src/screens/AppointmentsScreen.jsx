import React from 'react'
import { useNavigate } from 'react-router-dom'
import {
  CalendarCheck,
  Calendar,
  Clock,
  MapPin,
  Star,
  CheckCircle2,
  XCircle,
  AlertCircle,
} from 'lucide-react'
import Header from '../components/Header'
import BottomNav from '../components/BottomNav'
import { useApp } from '../context/AppContext'

export default function AppointmentsScreen() {
  const navigate = useNavigate()
  const { appointments, setChosenDoctorId } = useApp()

  const handleReview = (apt) => {
    setChosenDoctorId(apt.doctorId)
    navigate('/review', { state: { appointment: apt } })
  }

  return (
    <div className="flex-1 flex flex-col justify-between bg-[#F7F5EF] select-none">
      {/* Top Header */}
      <Header title="My Appointments" showBack={false} />

      {/* Main List */}
      <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
        
        <div>
          <h2 className="text-xl font-extrabold font-heading text-[#0F3D3E]">
            Consultations
          </h2>
          <p className="text-xs text-[#52686A]">
            Upcoming visits and verified past consultations
          </p>
        </div>

        {appointments.length === 0 ? (
          <div className="bg-white border border-[#D6E3DE] rounded-2xl p-8 text-center space-y-3 shadow-sm my-6">
            <Calendar className="w-12 h-12 text-[#82999B] mx-auto opacity-60" />
            <h3 className="text-sm font-bold text-[#0F3D3E]">No Appointments Yet</h3>
            <p className="text-xs text-[#52686A]">
              Explore verified doctors and reserve your slot in just a few taps.
            </p>
            <button
              onClick={() => navigate('/symptoms')}
              className="px-4 py-2 bg-[#137A6E] text-white rounded-xl text-xs font-bold"
            >
              Start Symptom Guide
            </button>
          </div>
        ) : (
          <div className="space-y-3.5">
            {appointments.map((apt) => {
              const isCompleted = apt.status === 'Completed'
              const isCancelled = apt.status === 'Cancelled'

              return (
                <div
                  key={apt.id}
                  className="bg-white border border-[#D6E3DE] rounded-2xl p-4 shadow-sm space-y-3"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <span
                        className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase mb-1 ${
                          isCompleted
                            ? 'bg-[#E7F0EC] text-[#137A6E]'
                            : isCancelled
                            ? 'bg-[#FDECE8] text-[#C73E1D]'
                            : 'bg-[#6FD3BF]/30 text-[#0F3D3E]'
                        }`}
                      >
                        {apt.status || 'Confirmed'}
                      </span>
                      <h3 className="text-sm font-extrabold text-[#0F3D3E]">
                        {apt.doctorName}
                      </h3>
                      <p className="text-xs font-semibold text-[#1A8A7D]">
                        {apt.specialty}
                      </p>
                    </div>

                    <span className="text-sm font-extrabold text-[#0F3D3E]">
                      ₹{apt.fee}
                    </span>
                  </div>

                  <div className="space-y-1.5 text-xs text-[#17302F]">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-3.5 h-3.5 text-[#137A6E]" />
                      <span className="font-semibold">{apt.date}</span>
                      <span>•</span>
                      <Clock className="w-3.5 h-3.5 text-[#137A6E]" />
                      <span className="font-semibold">{apt.time}</span>
                    </div>
                    <div className="flex items-center gap-2 text-[#52686A]">
                      <MapPin className="w-3.5 h-3.5 text-[#137A6E] shrink-0" />
                      <span className="truncate">{apt.hospital}</span>
                    </div>
                  </div>

                  {/* Actions row */}
                  <div className="pt-2.5 border-t border-[#D6E3DE]/70 flex items-center justify-between">
                    <span className="text-[11px] text-[#52686A]">
                      {isCompleted ? 'Visit completed' : isCancelled ? 'Booking cancelled' : 'Pay at clinic reception'}
                    </span>

                    {isCompleted && (
                      <button
                        onClick={() => handleReview(apt)}
                        disabled={apt.hasReviewed}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 shadow-sm ${
                          apt.hasReviewed
                            ? 'bg-[#E7F0EC] text-[#82999B] cursor-default'
                            : 'bg-[#137A6E] text-white hover:bg-[#0F3D3E]'
                        }`}
                      >
                        <Star className="w-3 h-3 fill-current" />
                        <span>{apt.hasReviewed ? 'Reviewed' : 'Review Visit'}</span>
                      </button>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        )}

      </div>

      {/* Bottom Navigation */}
      <BottomNav />
    </div>
  )
}
