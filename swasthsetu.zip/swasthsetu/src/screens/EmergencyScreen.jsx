import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  AlertTriangle,
  PhoneCall,
  MapPin,
  Ambulance,
  Phone,
  ShieldAlert,
  Copy,
  Check,
  Navigation,
  ExternalLink,
} from 'lucide-react'
import Header from '../components/Header'
import BottomNav from '../components/BottomNav'

export default function EmergencyScreen() {
  const navigate = useNavigate()
  const [coords, setCoords] = useState(null)
  const [locLoading, setLocLoading] = useState(false)
  const [locCopied, setLocCopied] = useState(false)
  const [locError, setLocError] = useState(null)

  const handleGetLocation = () => {
    setLocLoading(true)
    setLocError(null)

    if (!navigator.geolocation) {
      setCoords({ lat: 18.5793, lng: 73.9787 }) // Default Wagholi, Pune coordinates
      setLocLoading(false)
      return
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        setCoords({
          lat: position.coords.latitude.toFixed(4),
          lng: position.coords.longitude.toFixed(4),
        })
        setLocLoading(false)
      },
      (error) => {
        // Fallback to Wagholi, Pune coordinates if permission denied
        setCoords({ lat: 18.5793, lng: 73.9787 })
        setLocLoading(false)
      },
      { timeout: 5000 }
    )
  }

  const mapLink = coords
    ? `https://maps.google.com/?q=${coords.lat},${coords.lng}`
    : 'https://maps.google.com/?q=18.5793,73.9787'

  const copyToClipboard = () => {
    navigator.clipboard?.writeText(mapLink)
    setLocCopied(true)
    setTimeout(() => setLocCopied(false), 2500)
  }

  return (
    <div className="flex-1 flex flex-col justify-between bg-[#F7F5EF] select-none">
      {/* Top Header */}
      <Header title="Emergency Support" backTo="/home" />

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
        
        {/* Urgent Alert Banner */}
        <div className="p-3.5 bg-[#FDECE8] border border-[#F8B4A6] rounded-2xl flex items-center gap-2.5">
          <ShieldAlert className="w-5 h-5 text-[#C73E1D] shrink-0" />
          <p className="text-xs text-[#C73E1D] font-bold leading-tight">
            Never delay calling local emergency services.
          </p>
        </div>

        {/* Hero Emergency Section */}
        <div className="bg-white border-2 border-[#F8B4A6] rounded-3xl p-5 shadow-sm text-center flex flex-col items-center">
          <div className="w-16 h-16 rounded-full bg-[#FDECE8] flex items-center justify-center mb-2.5 text-[#C73E1D] relative shadow-inner">
            <AlertTriangle className="w-8 h-8 text-[#C73E1D]" />
            <span className="absolute -top-1 -right-1 w-3.5 h-3.5 rounded-full bg-[#C73E1D] animate-ping" />
          </div>

          <h2 className="text-xl font-extrabold font-heading text-[#0F3D3E] mb-1">
            Emergency? Need help now?
          </h2>
          <p className="text-xs text-[#52686A] max-w-xs mb-4">
            Connect immediately to national first responders for critical or life-threatening situations.
          </p>

          {/* Core Call Emergency Button (112) with tel: link */}
          <a
            href="tel:112"
            className="tap-target w-full bg-[#C73E1D] hover:bg-[#a53216] active:scale-[0.98] text-white font-extrabold text-base rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-[#C73E1D]/25 transition-all duration-200 mb-3"
          >
            <PhoneCall className="w-5 h-5" />
            <span>Call Emergency (112)</span>
          </a>

          {/* Share Current Location using navigator.geolocation */}
          <div className="w-full">
            <button
              onClick={handleGetLocation}
              disabled={locLoading}
              className="w-full py-3 px-3 bg-[#F7F5EF] border border-[#D6E3DE] rounded-xl text-xs font-bold text-[#17302F] hover:bg-[#E7F0EC] transition-all flex items-center justify-center gap-2 shadow-sm"
            >
              <Navigation className={`w-4 h-4 text-[#C73E1D] ${locLoading ? 'animate-spin' : ''}`} />
              <span>{locLoading ? 'Detecting GPS...' : 'Share Current Location'}</span>
            </button>

            {/* Coordinates & Copyable Maps Link */}
            {coords && (
              <div className="mt-2.5 p-3 bg-[#E7F0EC] rounded-xl text-left text-xs space-y-1.5 border border-[#6FD3BF]/40">
                <div className="flex items-center justify-between text-[#0F3D3E] font-bold">
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-[#137A6E]" />
                    GPS: {coords.lat}° N, {coords.lng}° E
                  </span>
                  <span className="text-[10px] text-[#137A6E] font-extrabold">Active</span>
                </div>

                <div className="flex items-center justify-between bg-white px-2.5 py-1.5 rounded-lg border border-[#D6E3DE]">
                  <span className="text-[11px] text-[#52686A] truncate max-w-[200px]">
                    {mapLink}
                  </span>
                  <button
                    onClick={copyToClipboard}
                    className="text-xs font-bold text-[#137A6E] hover:underline flex items-center gap-1 shrink-0 ml-2"
                  >
                    {locCopied ? (
                      <>
                        <Check className="w-3 h-3" /> Copied!
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" /> Copy
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Card: Call Ambulance */}
        <div className="bg-white border border-[#D6E3DE] rounded-2xl p-4 shadow-sm space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#FDECE8] flex items-center justify-center text-[#C73E1D] shrink-0">
              <Ambulance className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-extrabold text-[#0F3D3E]">
                Call Ambulance (108)
              </h3>
              <p className="text-[11px] text-[#C73E1D] font-bold">
                Ambulance dispatch with live GPS: coming soon with verified partners
              </p>
            </div>
          </div>

          <p className="text-xs text-[#52686A] leading-snug">
            Free state emergency medical service for prompt hospital transit in Maharashtra.
          </p>

          <a
            href="tel:108"
            className="w-full py-2.5 bg-[#137A6E] hover:bg-[#0F3D3E] text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-colors shadow-sm"
          >
            <Phone className="w-4 h-4" />
            <span>Call 108 Ambulance Hotline</span>
          </a>
        </div>

        {/* 24/7 Nearest Trauma & Casualty Info */}
        <div className="bg-white border border-[#D6E3DE] rounded-2xl p-4 shadow-sm space-y-2">
          <h3 className="text-xs font-bold font-heading text-[#0F3D3E] uppercase tracking-wider">
            Nearest Emergency Hospital (Wagholi)
          </h3>
          <div className="flex items-start justify-between text-xs">
            <div>
              <p className="font-bold text-[#0F3D3E]">Sahyadri Super Specialty Hospital</p>
              <p className="text-[#52686A] text-[11px]">Nagar Road, Wagholi • 2.5 km away</p>
            </div>
            <a
              href="tel:02067270000"
              className="text-xs font-bold text-[#137A6E] underline"
            >
              Call Desk
            </a>
          </div>
        </div>

      </div>

      {/* Bottom Navigation */}
      <BottomNav />
    </div>
  )
}
