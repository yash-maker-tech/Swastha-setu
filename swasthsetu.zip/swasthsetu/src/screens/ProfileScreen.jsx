import React from 'react'
import { useNavigate } from 'react-router-dom'
import {
  User,
  Globe,
  ShieldCheck,
  ChevronRight,
  Heart,
  FileHeart,
  Info,
} from 'lucide-react'
import Header from '../components/Header'
import BottomNav from '../components/BottomNav'
import { LANGUAGES } from '../data'
import { useApp } from '../context/AppContext'

export default function ProfileScreen() {
  const navigate = useNavigate()
  const { language } = useApp()

  const currentLang = LANGUAGES.find(l => l.code === language) || LANGUAGES[0]

  return (
    <div className="flex-1 flex flex-col justify-between bg-[#F7F5EF] select-none">
      {/* Top Header */}
      <Header title="Profile" showBack={false} />

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
        
        {/* Simple User / Guest Card */}
        <div className="bg-white border border-[#D6E3DE] rounded-2xl p-4 shadow-sm flex items-center gap-3.5">
          <div className="w-14 h-14 rounded-2xl bg-[#E7F0EC] flex items-center justify-center text-[#137A6E]">
            <User className="w-7 h-7" />
          </div>
          <div>
            <h2 className="text-base font-extrabold text-[#0F3D3E]">
              Patient Profile
            </h2>
            <p className="text-xs text-[#52686A]">
              Location: Wagholi, Pune
            </p>
            <span className="inline-block mt-1 text-[10px] font-bold text-[#137A6E] bg-[#E7F0EC] px-2 py-0.5 rounded-full">
              Open Access • No Membership Needed
            </span>
          </div>
        </div>

        {/* Language Setting Row */}
        <div className="bg-white border border-[#D6E3DE] rounded-2xl overflow-hidden shadow-sm">
          <button
            onClick={() => navigate('/language')}
            className="w-full p-4 flex items-center justify-between text-left hover:bg-[#F7F5EF] transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-[#E7F0EC] flex items-center justify-center text-[#137A6E]">
                <Globe className="w-5 h-5" />
              </div>
              <div>
                <span className="text-sm font-bold text-[#0F3D3E] block">
                  Language Setting
                </span>
                <span className="text-xs text-[#52686A]">
                  {currentLang.native} ({currentLang.name})
                </span>
              </div>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-[#137A6E] font-bold">
              <span>Change</span>
              <ChevronRight className="w-4 h-4 text-[#82999B]" />
            </div>
          </button>
        </div>

        {/* Clear "About" Note */}
        <div className="bg-white border border-[#D6E3DE] rounded-2xl p-4 shadow-sm space-y-3">
          <div className="flex items-center gap-2">
            <FileHeart className="w-5 h-5 text-[#137A6E]" />
            <h3 className="text-sm font-extrabold font-heading text-[#0F3D3E]">
              About SwasthSetu
            </h3>
          </div>

          <p className="text-xs text-[#17302F] font-semibold">
            Tagline: "From symptoms to the right care"
          </p>

          <p className="text-xs text-[#52686A] leading-relaxed">
            SwasthSetu is a healthcare navigation application designed to guide patients directly to the right specialist doctor based on familiar, everyday symptoms.
          </p>

          <div className="p-3 bg-[#E7F0EC] rounded-xl border border-[#6FD3BF]/50 flex items-start gap-2">
            <ShieldCheck className="w-4 h-4 text-[#137A6E] shrink-0 mt-0.5" />
            <p className="text-[11px] text-[#0F3D3E] leading-tight font-medium">
              <strong>Core Healthcare Standard:</strong> SwasthSetu NEVER diagnoses diseases or predicts medical conditions. It empowers patients with clear navigation and transparent fee discovery.
            </p>
          </div>

          <div className="pt-2 border-t border-[#D6E3DE]/60 flex items-center justify-between text-[11px] text-[#82999B]">
            <span>Version 1.0 (Prototype)</span>
            <span>Made with Care for Pune</span>
          </div>
        </div>

      </div>

      {/* Bottom Navigation */}
      <BottomNav />
    </div>
  )
}
