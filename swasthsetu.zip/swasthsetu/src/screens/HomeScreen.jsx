import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Search,
  Stethoscope,
  ListFilter,
  Ambulance,
  ArrowRight,
  Thermometer,
  Activity,
  Sparkles,
  CalendarHeart,
  ChevronRight,
  MapPin,
  Info,
} from 'lucide-react'
import Header from '../components/Header'
import BottomNav from '../components/BottomNav'
import { useApp } from '../context/AppContext'
import { t } from '../i18n'

export default function HomeScreen() {
  const navigate = useNavigate()
  const { filters, toggleSymptom, clearSymptoms, language } = useApp()
  const [searchQuery, setSearchQuery] = useState('')

  const handleQuickSymptom = (symptomId) => {
    clearSymptoms()
    toggleSymptom(symptomId)
    navigate('/specialist')
  }

  const handleSearchSubmit = (e) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      navigate('/symptoms')
    }
  }

  const popularSearches = [
    { id: 'fever', labelKey: 'fever', icon: Thermometer, color: '#137A6E', bg: '#E7F0EC' },
    { id: 'stomach_pain', labelKey: 'stomach_pain', icon: Activity, color: '#1A8A7D', bg: '#E7F0EC' },
    { id: 'acne_skin', labelKey: 'acne_skin', icon: Sparkles, color: '#0F3D3E', bg: '#E7F0EC' },
    { id: 'menstrual', labelKey: 'menstrual', icon: CalendarHeart, color: '#137A6E', bg: '#E7F0EC' },
  ]

  return (
    <div className="flex-1 flex flex-col justify-between bg-[#F7F5EF] select-none">
      {/* Top Header */}
      <Header showBack={false} />

      {/* Scrollable Body Content */}
      <div className="flex-1 overflow-y-auto px-5 py-4 space-y-5">
        
        {/* User Greeting & Location */}
        <div>
          <div className="flex items-center gap-1.5 text-xs text-[#52686A] font-semibold mb-1">
            <MapPin className="w-3.5 h-3.5 text-[#137A6E]" />
            <span>Near {filters.location}</span>
          </div>
          <h2 className="text-2xl font-extrabold font-heading text-[#0F3D3E] tracking-tight">
            {t('greeting', language)}
          </h2>
          <p className="text-sm text-[#52686A]">
            {t('howCanWeHelp', language)}
          </p>
        </div>

        {/* Search Bar */}
        <form onSubmit={handleSearchSubmit} className="relative">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t('searchPlaceholder', language)}
            className="w-full bg-white border border-[#D6E3DE] rounded-2xl py-3.5 pl-11 pr-4 text-sm font-medium text-[#17302F] placeholder-[#82999B] focus:outline-none focus:border-[#137A6E] focus:ring-2 focus:ring-[#137A6E]/15 shadow-sm"
          />
          <Search className="w-5 h-5 text-[#52686A] absolute left-3.5 top-1/2 -translate-y-1/2" />
        </form>

        {/* 3 Quick Action Cards */}
        <div className="grid grid-cols-3 gap-2.5">
          {/* Card 1: Find a Doctor */}
          <button
            onClick={() => navigate('/filters')}
            className="bg-white border border-[#D6E3DE] rounded-2xl p-3 flex flex-col items-center text-center gap-2 hover:border-[#137A6E] transition-all shadow-sm active:scale-95 group"
          >
            <div className="w-11 h-11 rounded-2xl bg-[#E7F0EC] group-hover:bg-[#6FD3BF]/30 flex items-center justify-center transition-colors">
              <Stethoscope className="w-6 h-6 text-[#137A6E]" />
            </div>
            <span className="text-xs font-bold text-[#0F3D3E] leading-tight">
              {t('findDoctor', language)}
            </span>
          </button>

          {/* Card 2: Symptom Guide */}
          <button
            onClick={() => navigate('/symptoms')}
            className="bg-white border border-[#D6E3DE] rounded-2xl p-3 flex flex-col items-center text-center gap-2 hover:border-[#137A6E] transition-all shadow-sm active:scale-95 group"
          >
            <div className="w-11 h-11 rounded-2xl bg-[#E7F0EC] group-hover:bg-[#6FD3BF]/30 flex items-center justify-center transition-colors">
              <ListFilter className="w-6 h-6 text-[#137A6E]" />
            </div>
            <span className="text-xs font-bold text-[#0F3D3E] leading-tight">
              {t('symptomGuide', language)}
            </span>
          </button>

          {/* Card 3: Book Ambulance */}
          <button
            onClick={() => navigate('/emergency')}
            className="bg-white border border-[#D6E3DE] rounded-2xl p-3 flex flex-col items-center text-center gap-2 hover:border-[#C73E1D] transition-all shadow-sm active:scale-95 group"
          >
            <div className="w-11 h-11 rounded-2xl bg-[#FDECE8] group-hover:bg-[#F8B4A6]/40 flex items-center justify-center transition-colors">
              <Ambulance className="w-6 h-6 text-[#C73E1D]" />
            </div>
            <span className="text-xs font-bold text-[#C73E1D] leading-tight">
              {t('bookAmbulance', language)}
            </span>
          </button>
        </div>

        {/* Mint Guided Banner (Hero Card) */}
        <div
          onClick={() => navigate('/symptoms')}
          role="button"
          tabIndex={0}
          className="w-full bg-gradient-to-r from-[#E7F0EC] to-[#F0F7F4] border border-[#6FD3BF]/70 rounded-2xl p-4 flex items-center justify-between cursor-pointer shadow-sm hover:shadow-md transition-all active:scale-[0.99] group"
        >
          <div className="flex-1 pr-3">
            <span className="inline-block px-2.5 py-0.5 rounded-full bg-[#6FD3BF]/40 text-[#0F3D3E] text-[11px] font-extrabold uppercase tracking-wider mb-1.5">
              Guided Care
            </span>
            <h3 className="text-base font-extrabold font-heading text-[#0F3D3E] leading-tight mb-1">
              {t('guidedBannerTitle', language)}
            </h3>
            <p className="text-xs text-[#52686A] mb-2.5 leading-snug">
              {t('guidedBannerSub', language)}
            </p>
            <div className="inline-flex items-center gap-1 text-xs font-bold text-[#137A6E] group-hover:gap-1.5 transition-all">
              <span>{t('startSymptomCheck', language)}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </div>
          </div>

          <div className="w-20 h-20 rounded-2xl overflow-hidden shrink-0 border-2 border-white shadow-sm bg-[#6FD3BF]/30">
            <img
              src="https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&q=80&w=200"
              alt="Doctor guidance"
              className="w-full h-full object-cover"
            />
          </div>
        </div>

        {/* Popular Searches Row */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-sm font-bold font-heading text-[#0F3D3E]">
              {t('popularSearches', language)}
            </h4>
            <button
              onClick={() => navigate('/symptoms')}
              className="text-xs font-bold text-[#137A6E] hover:underline flex items-center gap-0.5"
            >
              {t('seeMore', language)} <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            {popularSearches.map((item) => {
              const Icon = item.icon
              return (
                <button
                  key={item.id}
                  onClick={() => handleQuickSymptom(item.id)}
                  className="bg-white border border-[#D6E3DE] rounded-xl p-3 flex items-center gap-2.5 hover:border-[#137A6E] transition-all text-left shadow-sm active:scale-95"
                >
                  <div
                    className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
                    style={{ backgroundColor: item.bg }}
                  >
                    <Icon className="w-4 h-4" style={{ color: item.color }} />
                  </div>
                  <span className="text-xs font-bold text-[#17302F] truncate">
                    {t(item.labelKey, language)}
                  </span>
                </button>
              )
            })}
          </div>
        </div>

        {/* Informative reassurance footer note */}
        <div className="p-3.5 rounded-2xl bg-white border border-[#D6E3DE] flex items-start gap-3">
          <Info className="w-4 h-4 text-[#137A6E] shrink-0 mt-0.5" />
          <p className="text-[11px] text-[#52686A] leading-relaxed">
            {t('homeDisclaimer', language)}
          </p>
        </div>

      </div>

      {/* Bottom Navigation */}
      <BottomNav />
    </div>
  )
}
