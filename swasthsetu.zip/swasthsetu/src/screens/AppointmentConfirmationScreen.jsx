import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  CheckCircle2,
  Calendar,
  Clock,
  MapPin,
  CalendarPlus,
  ArrowRight,
  ShieldCheck,
  Check,
  XCircle,
  FileText,
} from 'lucide-react'
import Header from '../components/Header'
import { useApp } from '../context/AppContext'

export default function AppointmentConfirmationScreen() {
  const navigate = useNavigate()
  const { booking, chosenDoctor, cancelAppointment } = useApp()
  const [calendarDownloaded, setCalendarDownloaded] = useState(false)
  const [showDetailsModal, setShowDetailsModal] = useState(false)
  const [isCancelled, setIsCancelled] = useState(false)

  const doctor = booking
    ? {
        id: booking.doctorId,
        name: booking.doctorName,
        specialty: booking.specialty,
        hospital: booking.hospital,
        date: booking.date,
        time: booking.time,
        fee: booking.fee,
        appointmentId: booking.id,
      }
    : {
        id: chosenDoctor.id,
        name: chosenDoctor.name,
        specialty: chosenDoctor.specialty,
        hospital: chosenDoctor.hospital,
        date: 'Today, 31 Oct 2026',
        time: '11:00 AM',
        fee: chosenDoctor.fee,
        appointmentId: 'apt-temp',
      }

  // Generate and download .ics calendar file
  const downloadIcsFile = () => {
    const icsData = [
      'BEGIN:VCALENDAR',
      'VERSION:2.0',
      'PRODID:-//SwasthSetu//Healthcare Navigation//EN',
      'BEGIN:VEVENT',
      `SUMMARY:Doctor Visit - ${doctor.name} (${doctor.specialty})`,
      `DESCRIPTION:Consultation with ${doctor.name} at ${doctor.hospital}. Fee: Rs ${doctor.fee}. Booked via SwasthSetu.`,
      `LOCATION:${doctor.hospital}`,
      `DTSTART:20261031T110000Z`,
      `DTEND:20261031T113000Z`,
      'STATUS:CONFIRMED',
      'END:VEVENT',
      'END:VCALENDAR',
    ].join('\r\n')

    const blob = new Blob([icsData], { type: 'text/calendar;charset=utf-8' })
    const url = window.URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.setAttribute('download', `SwasthSetu-Appointment-${doctor.name.replace(/\s+/g, '_')}.ics`)
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    window.URL.revokeObjectURL(url)

    setCalendarDownloaded(true)
  }

  const handleCancel = () => {
    if (window.confirm('Are you sure you want to cancel or reschedule this appointment?')) {
      if (doctor.appointmentId) {
        cancelAppointment(doctor.appointmentId)
      }
      setIsCancelled(true)
    }
  }

  return (
    <div className="flex-1 flex flex-col justify-between bg-[#F7F5EF] select-none">
      {/* Top Header */}
      <Header title="Appointment Confirmation" showBack={false} />

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto px-5 py-6 space-y-5 flex flex-col items-center text-center">
        
        {/* Animated Green Check Badge */}
        <div className="relative my-1">
          <div className="w-20 h-20 rounded-full bg-[#E7F0EC] border-4 border-[#6FD3BF]/60 flex items-center justify-center shadow-md animate-pulse">
            <CheckCircle2 className="w-12 h-12 text-[#137A6E]" />
          </div>
          <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-[#137A6E] flex items-center justify-center text-white text-xs font-extrabold shadow-sm">
            ✓
          </div>
        </div>

        <div>
          <h2 className="text-2xl font-extrabold font-heading text-[#0F3D3E] mb-1">
            {isCancelled ? 'Appointment Cancelled' : 'Your Appointment is Confirmed!'}
          </h2>
          <p className="text-xs text-[#52686A] max-w-xs leading-relaxed">
            {isCancelled
              ? 'Your booking has been cancelled. You can choose a new slot whenever you are ready.'
              : 'A confirmation has been saved to your app and dispatched to your phone.'}
          </p>
        </div>

        {/* Doctor Details Card */}
        <div className="w-full bg-white border border-[#D6E3DE] rounded-2xl p-4 shadow-sm text-left space-y-3">
          <div className="flex items-center gap-3 pb-3 border-b border-[#D6E3DE]/70">
            <div className="w-12 h-12 rounded-xl bg-[#E7F0EC] overflow-hidden shrink-0 border border-[#D6E3DE]">
              <img
                src={chosenDoctor.image}
                alt={doctor.name}
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              <h3 className="text-sm font-extrabold text-[#0F3D3E]">
                {doctor.name}
              </h3>
              <p className="text-xs font-semibold text-[#1A8A7D]">
                {doctor.specialty}
              </p>
            </div>
          </div>

          <div className="space-y-2 text-xs">
            <div className="flex items-center gap-2 text-[#17302F]">
              <Calendar className="w-4 h-4 text-[#137A6E] shrink-0" />
              <span className="font-bold">{doctor.date}</span>
            </div>

            <div className="flex items-center gap-2 text-[#17302F]">
              <Clock className="w-4 h-4 text-[#137A6E] shrink-0" />
              <span className="font-bold">{doctor.time}</span>
            </div>

            <div className="flex items-center gap-2 text-[#52686A]">
              <MapPin className="w-4 h-4 text-[#137A6E] shrink-0" />
              <span className="truncate">{doctor.hospital}</span>
            </div>
          </div>

          <div className="pt-2.5 border-t border-[#D6E3DE]/70 flex items-center justify-between text-xs">
            <span className="text-[#52686A]">Consultation Fee to pay at clinic</span>
            <span className="text-sm font-extrabold text-[#0F3D3E]">₹{doctor.fee}</span>
          </div>
        </div>

        {/* 3 Core Action Buttons requested by user */}
        <div className="w-full space-y-2.5">
          {/* Button 1: Add to Calendar (download .ics) */}
          <button
            onClick={downloadIcsFile}
            className="w-full py-3 px-3 bg-white border border-[#D6E3DE] rounded-xl text-xs font-bold text-[#137A6E] hover:bg-[#E7F0EC] transition-all flex items-center justify-center gap-2 shadow-sm active:scale-98"
          >
            {calendarDownloaded ? (
              <>
                <Check className="w-4 h-4 text-[#137A6E]" />
                <span>Downloaded (.ics) Calendar Invite</span>
              </>
            ) : (
              <>
                <CalendarPlus className="w-4 h-4" />
                <span>Add to Calendar (Download .ics)</span>
              </>
            )}
          </button>

          {/* Button 2: View Appointment Details */}
          <button
            onClick={() => setShowDetailsModal(true)}
            className="w-full py-3 px-3 bg-[#E7F0EC] rounded-xl text-xs font-bold text-[#0F3D3E] hover:bg-[#D6E3DE] transition-all flex items-center justify-center gap-2 shadow-sm"
          >
            <FileText className="w-4 h-4 text-[#137A6E]" />
            <span>View Appointment Details</span>
          </button>

          {/* Button 3: Cancel / Reschedule */}
          {!isCancelled ? (
            <button
              onClick={handleCancel}
              className="w-full py-2.5 px-3 bg-white border border-[#F8B4A6] rounded-xl text-xs font-bold text-[#C73E1D] hover:bg-[#FDECE8] transition-all flex items-center justify-center gap-2"
            >
              <XCircle className="w-4 h-4" />
              <span>Cancel / Reschedule</span>
            </button>
          ) : (
            <button
              onClick={() => navigate('/doctors')}
              className="w-full py-2.5 px-3 bg-[#137A6E] text-white rounded-xl text-xs font-bold"
            >
              Choose New Slot
            </button>
          )}
        </div>

        {/* Patient notice */}
        <div className="p-3 bg-white rounded-xl border border-[#D6E3DE] flex items-center gap-2 text-left">
          <ShieldCheck className="w-4 h-4 text-[#137A6E] shrink-0" />
          <p className="text-[11px] text-[#52686A] leading-tight">
            Please arrive 10 minutes before your appointment time. Show this screen or your SMS confirmation at reception.
          </p>
        </div>

      </div>

      {/* Details Modal */}
      {showDetailsModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-5 max-w-xs w-full space-y-3 shadow-xl text-left">
            <h3 className="text-sm font-extrabold text-[#0F3D3E]">
              Appointment Summary
            </h3>
            <div className="text-xs space-y-2 text-[#52686A]">
              <div><strong>Booking ID:</strong> {doctor.appointmentId}</div>
              <div><strong>Doctor:</strong> {doctor.name}</div>
              <div><strong>Specialty:</strong> {doctor.specialty}</div>
              <div><strong>Clinic:</strong> {doctor.hospital}</div>
              <div><strong>Date & Time:</strong> {doctor.date} at {doctor.time}</div>
              <div><strong>Fee:</strong> ₹{doctor.fee} (Pay on visit)</div>
              <div><strong>Status:</strong> {isCancelled ? 'Cancelled' : 'Confirmed'}</div>
            </div>
            <button
              onClick={() => setShowDetailsModal(false)}
              className="w-full py-2 bg-[#137A6E] text-white text-xs font-bold rounded-xl mt-2"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* Sticky Bottom Done Button */}
      <div className="bg-white border-t border-[#D6E3DE] p-4 shadow-lg shrink-0">
        <button
          onClick={() => navigate('/appointments')}
          className="tap-target w-full bg-[#137A6E] hover:bg-[#0F3D3E] active:scale-[0.98] text-white font-bold text-base rounded-xl flex items-center justify-center gap-2 shadow-md transition-all duration-200"
        >
          <span>View in My Appointments</span>
          <ArrowRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  )
}
