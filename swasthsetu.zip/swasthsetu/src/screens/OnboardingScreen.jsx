import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Sparkles,
  ShieldCheck,
  CalendarCheck,
  AlertCircle,
  ArrowRight,
  CheckCircle2,
  Coins,
  Clock,
  Globe,
  HeartPulse,
} from 'lucide-react'
import { ONBOARDING_SLIDES } from '../data'

export default function OnboardingScreen() {
  const navigate = useNavigate()
  const [currentStep, setCurrentStep] = useState(0)

  const handleNext = () => {
    if (currentStep < ONBOARDING_SLIDES.length - 1) {
      setCurrentStep(prev => prev + 1)
    } else {
      navigate('/home')
    }
  }

  const handleSkip = () => {
    navigate('/home')
  }

  const slide = ONBOARDING_SLIDES[currentStep]

  const getIcon = (iconName) => {
    switch (iconName) {
      case 'Sparkles':
        return <Sparkles className="w-5 h-5 text-[#137A6E]" />
      case 'ShieldCheck':
        return <ShieldCheck className="w-5 h-5 text-[#1A8A7D]" />
      case 'CalendarCheck':
        return <CalendarCheck className="w-5 h-5 text-[#137A6E]" />
      case 'AlertCircle':
        return <AlertCircle className="w-5 h-5 text-[#C73E1D]" />
      case 'CheckCircle2':
        return <CheckCircle2 className="w-5 h-5 text-[#137A6E]" />
      case 'Coins':
        return <Coins className="w-5 h-5 text-[#137A6E]" />
      case 'Clock':
        return <Clock className="w-5 h-5 text-[#1A8A7D]" />
      case 'Globe':
        return <Globe className="w-5 h-5 text-[#0F3D3E]" />
      default:
        return <HeartPulse className="w-5 h-5 text-[#137A6E]" />
    }
  }

  return (
    <div className="flex-1 flex flex-col justify-between p-6 bg-[#F7F5EF] select-none">
      {/* Top Header bar with Skip */}
      <div className="flex items-center justify-between pt-2">
        <div className="flex items-center gap-1.5">
          <div className="w-7 h-7 rounded-lg bg-[#E7F0EC] flex items-center justify-center">
            <HeartPulse className="w-4 h-4 text-[#137A6E]" />
          </div>
          <span className="font-heading font-extrabold text-[#0F3D3E] text-base">
            SwasthSetu
          </span>
        </div>

        <button
          onClick={handleSkip}
          className="text-sm font-bold text-[#52686A] hover:text-[#0F3D3E] px-3 py-1.5 rounded-lg hover:bg-black/5 transition-colors"
        >
          Skip
        </button>
      </div>

      {/* Main Slide Content */}
      <div className="my-auto flex flex-col pt-4">
        {/* Step indicator pill */}
        <div className="inline-flex self-start items-center gap-1.5 px-3 py-1 rounded-full bg-[#E7F0EC] text-[#137A6E] text-xs font-bold mb-4">
          Step {currentStep + 1} of {ONBOARDING_SLIDES.length}
        </div>

        <h2 className="text-2xl font-extrabold font-heading text-[#0F3D3E] leading-snug mb-2">
          {slide.title}
        </h2>
        <p className="text-sm text-[#52686A] leading-relaxed mb-6">
          {slide.subtitle}
        </p>

        {/* Feature Highlights Grid / Cards */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          {slide.bullets.map((bullet, idx) => (
            <div
              key={idx}
              className="bg-white border border-[#D6E3DE] rounded-2xl p-3.5 flex flex-col items-start gap-2.5 shadow-sm"
            >
              <div className="w-10 h-10 rounded-xl bg-[#E7F0EC] flex items-center justify-center">
                {getIcon(bullet.icon)}
              </div>
              <span className="text-xs font-bold text-[#17302F] leading-snug">
                {bullet.text}
              </span>
            </div>
          ))}
        </div>

        {/* Informative reassurance banner */}
        <div className="p-3 bg-[#E7F0EC] border border-[#6FD3BF]/40 rounded-xl flex items-center gap-2.5">
          <ShieldCheck className="w-5 h-5 text-[#137A6E] shrink-0" />
          <p className="text-xs text-[#17302F] font-medium leading-tight">
            Navigation guidance only. We guide you to doctors, never diagnosing illnesses.
          </p>
        </div>
      </div>

      {/* Bottom Controls */}
      <div className="w-full flex flex-col gap-4 pt-2">
        {/* Pagination Dots */}
        <div className="flex items-center justify-center gap-2">
          {ONBOARDING_SLIDES.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentStep(idx)}
              className={`h-2 rounded-full transition-all duration-300 ${
                idx === currentStep
                  ? 'w-7 bg-[#137A6E]'
                  : 'w-2 bg-[#D6E3DE] hover:bg-[#82999B]'
              }`}
              aria-label={`Go to slide ${idx + 1}`}
            />
          ))}
        </div>

        {/* Action Button */}
        <button
          onClick={handleNext}
          className="tap-target w-full bg-[#137A6E] hover:bg-[#0F3D3E] active:scale-[0.98] text-white font-bold text-base rounded-xl flex items-center justify-center gap-2 shadow-md transition-all"
        >
          <span>{currentStep === ONBOARDING_SLIDES.length - 1 ? 'Start Now' : 'Next'}</span>
          <ArrowRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  )
}
