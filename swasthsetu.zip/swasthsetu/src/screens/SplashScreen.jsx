import React, { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { ArrowRight, HeartPulse } from 'lucide-react'

export default function SplashScreen() {
  const navigate = useNavigate()

  // Optional auto advance or direct button tap
  useEffect(() => {
    const timer = setTimeout(() => {
      // Auto-advance if untouched
      // navigate('/onboarding')
    }, 4000)
    return () => clearTimeout(timer)
  }, [navigate])

  return (
    <div className="flex-1 flex flex-col justify-between p-6 bg-gradient-to-b from-[#F7F5EF] via-[#E7F0EC]/50 to-[#E7F0EC] relative overflow-hidden select-none">
      {/* Subtle organic background curves */}
      <div className="absolute top-10 -right-16 w-56 h-56 bg-[#6FD3BF]/15 rounded-full blur-2xl pointer-events-none" />
      <div className="absolute -bottom-10 -left-16 w-64 h-64 bg-[#137A6E]/10 rounded-full blur-2xl pointer-events-none" />

      {/* Top spacer */}
      <div className="pt-8 flex justify-center">
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/80 border border-[#D6E3DE] text-xs font-semibold text-[#137A6E]">
          <HeartPulse className="w-3.5 h-3.5 text-[#137A6E]" />
          Healthcare Navigation App
        </span>
      </div>

      {/* Center Branding */}
      <div className="flex flex-col items-center text-center my-auto px-2 z-10">
        {/* Large Logo Emblem */}
        <div className="relative mb-6">
          <div className="w-28 h-28 rounded-3xl bg-white border border-[#D6E3DE] shadow-xl flex items-center justify-center p-3 relative group">
            <svg
              viewBox="0 0 64 64"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="w-full h-full drop-shadow-md"
            >
              {/* Mint Heart glow */}
              <path
                d="M32 21C29.6 17.5 23.3 17 20.3 20.6C17.6 23.7 18.2 28.7 21.7 32.1L32 41.5L42.3 32.1C45.8 28.7 46.4 23.7 43.7 20.6C40.7 17 34.4 17.5 32 21Z"
                fill="#6FD3BF"
                fillOpacity="0.5"
              />
              {/* Deep Stethoscope Loop */}
              <path
                d="M22 25V31C22 36.523 26.477 41 32 41C37.523 41 42 36.523 42 31V25"
                stroke="#137A6E"
                strokeWidth="3.6"
                strokeLinecap="round"
              />
              <path
                d="M32 41V47"
                stroke="#137A6E"
                strokeWidth="3.6"
                strokeLinecap="round"
              />
              <circle cx="32" cy="49" r="4" fill="#0F3D3E" stroke="#137A6E" strokeWidth="2" />
              {/* Stethoscope earpieces */}
              <circle cx="22" cy="24" r="2.5" fill="#0F3D3E" />
              <circle cx="42" cy="24" r="2.5" fill="#0F3D3E" />
            </svg>
          </div>
          {/* Subtle pulse badge */}
          <div className="absolute -bottom-2 -right-2 bg-[#6FD3BF] text-[#0F3D3E] text-[10px] font-extrabold px-2 py-0.5 rounded-full shadow-sm border border-white">
            100% Free
          </div>
        </div>

        <h1 className="text-4xl font-extrabold font-heading text-[#0F3D3E] tracking-tight mb-2">
          SwasthSetu
        </h1>
        <p className="text-lg font-bold text-[#1A8A7D] mb-4">
          From symptoms to the right care
        </p>

        <p className="text-sm text-[#52686A] max-w-xs leading-relaxed">
          Healthcare made simple, accessible and closer to you. Finding the right specialist has never been easier.
        </p>

        {/* Peaceful nature / wave illustration motif */}
        <div className="mt-8 flex items-center justify-center gap-1.5 opacity-70">
          <span className="w-10 h-1 bg-[#6FD3BF] rounded-full"></span>
          <span className="w-3 h-1 bg-[#137A6E] rounded-full"></span>
          <span className="w-10 h-1 bg-[#6FD3BF] rounded-full"></span>
        </div>
      </div>

      {/* Bottom Action */}
      <div className="w-full flex flex-col gap-3 z-10 pb-2">
        <button
          onClick={() => navigate('/onboarding')}
          className="tap-target w-full bg-[#137A6E] hover:bg-[#0F3D3E] active:scale-[0.98] text-white font-bold text-lg rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-[#137A6E]/20 transition-all duration-200"
        >
          <span>Get Started</span>
          <ArrowRight className="w-5 h-5" />
        </button>

        <p className="text-center text-[11px] text-[#52686A]">
          Guidance only. Does not replace emergency medical diagnosis.
        </p>
      </div>
    </div>
  )
}
