import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Star,
  MapPin,
  SlidersHorizontal,
  Heart,
  Calendar,
  AlertCircle,
  RotateCcw,
  Sparkles,
} from 'lucide-react'
import Header from '../components/Header'
import { DOCTORS, determineSpecialist } from '../data'
import { useApp } from '../context/AppContext'

export default function DoctorListScreen() {
  const navigate = useNavigate()
  const { filters, resetFilters, selectedSymptoms, setChosenDoctorId } = useApp()
  const [activeSort, setActiveSort] = useState('Best Match')
  const [favorites, setFavorites] = useState({})

  const recommendation = determineSpecialist(selectedSymptoms)
  const targetSpecialty = recommendation.title || 'General Physician'
  const targetSpecialistKey = recommendation.specialistKey || 'general_physician'

  // Apply chosen filters
  let filteredDocs = DOCTORS.filter((doc) => {
    // 1. Fee / Budget Filter
    if (doc.fee > filters.maxBudget) return false

    // 2. Rating Filter
    if (filters.rating && doc.rating < filters.rating) return false

    // 3. Gender Filter
    if (filters.gender !== 'Any' && doc.gender !== filters.gender) return false

    // 4. Clinic / Hospital Type Filter
    if (filters.clinicType !== 'Any' && doc.clinicType !== filters.clinicType) return false

    // 5. Availability Filter
    if (filters.availability && filters.availability !== 'Any') {
      if (filters.availability === 'Today' && doc.availability !== 'Today') return false
      if (filters.availability === 'Tomorrow' && doc.availability !== 'Today' && doc.availability !== 'Tomorrow') return false
    }

    return true
  })

  // Sorting logic
  if (activeSort === 'Closest') {
    filteredDocs.sort((a, b) => a.distance - b.distance)
  } else if (activeSort === 'Lowest Fee') {
    filteredDocs.sort((a, b) => a.fee - b.fee)
  } else {
    // Best Match: ranks by specialist match, availability, distance, fee and rating
    filteredDocs.sort((a, b) => {
      const aSpecMatch = a.specialistKey === targetSpecialistKey ? 60 : 0
      const bSpecMatch = b.specialistKey === targetSpecialistKey ? 60 : 0

      const aAvailScore = a.availability === 'Today' ? 20 : (a.availability === 'Tomorrow' ? 10 : 0)
      const bAvailScore = b.availability === 'Today' ? 20 : (b.availability === 'Tomorrow' ? 10 : 0)

      // Score: high rating, lower fee, lower distance
      const scoreA = aSpecMatch + aAvailScore + (a.rating * 15) - (a.distance * 4) - (a.fee / 50)
      const scoreB = bSpecMatch + bAvailScore + (b.rating * 15) - (b.distance * 4) - (b.fee / 50)
      return scoreB - scoreA
    })
  }

  const toggleFavorite = (id, e) => {
    e.stopPropagation()
    setFavorites(prev => ({ ...prev, [id]: !prev[id] }))
  }

  const handleSelectDoctor = (doc) => {
    setChosenDoctorId(doc.id)
    navigate(`/doctor/${doc.id}`)
  }

  return (
    <div className="flex-1 flex flex-col justify-between bg-[#F7F5EF] select-none">
      {/* Top Header */}
      <Header
        title="Doctor Directory"
        backTo="/filters"
        rightAction={
          <button
            onClick={() => navigate('/filters')}
            className="w-9 h-9 rounded-full bg-white border border-[#D6E3DE] flex items-center justify-center text-[#137A6E] hover:bg-[#E7F0EC] transition-colors shadow-sm"
            title="Edit filters"
          >
            <SlidersHorizontal className="w-4 h-4" />
          </button>
        }
      />

      {/* Main List Area */}
      <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
        
        {/* Header Title specified by prompt: "Available <specialty>s near <location>" */}
        <div>
          <h2 className="text-xl font-extrabold font-heading text-[#0F3D3E]">
            Available {targetSpecialty}s near {filters.location}
          </h2>
          <p className="text-xs text-[#52686A] mt-0.5">
            Verified local practitioners • Transparent consultation fees
          </p>
        </div>

        {/* Sort Pills (Best Match, Closest, Lowest Fee) */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
          {['Best Match', 'Closest', 'Lowest Fee'].map((sortType) => (
            <button
              key={sortType}
              onClick={() => setActiveSort(sortType)}
              className={`px-3.5 py-1.5 rounded-full text-xs font-bold shrink-0 transition-all ${
                activeSort === sortType
                  ? 'bg-[#137A6E] text-white shadow-sm'
                  : 'bg-white border border-[#D6E3DE] text-[#52686A] hover:border-[#137A6E]'
              }`}
            >
              {sortType}
            </button>
          ))}
        </div>

        {/* Empty State */}
        {filteredDocs.length === 0 ? (
          <div className="bg-white border border-[#D6E3DE] rounded-2xl p-8 text-center space-y-3 shadow-sm my-6">
            <div className="w-12 h-12 rounded-full bg-[#E7F0EC] flex items-center justify-center mx-auto text-[#137A6E]">
              <AlertCircle className="w-6 h-6" />
            </div>
            <h3 className="text-sm font-extrabold text-[#0F3D3E]">
              No doctors match. Try widening your filters.
            </h3>
            <p className="text-xs text-[#52686A]">
              We couldn't find any doctor matching your current budget or availability filters.
            </p>
            <button
              onClick={() => resetFilters()}
              className="px-4 py-2 bg-[#137A6E] text-white rounded-xl text-xs font-bold inline-flex items-center gap-1.5 shadow-sm"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Filters</span>
            </button>
          </div>
        ) : (
          /* Doctor Cards */
          <div className="space-y-3.5">
            {filteredDocs.map((doc) => {
              const isFav = !!favorites[doc.id]

              return (
                <div
                  key={doc.id}
                  onClick={() => handleSelectDoctor(doc)}
                  className="bg-white border border-[#D6E3DE] rounded-2xl p-4 shadow-sm hover:border-[#137A6E] transition-all cursor-pointer group"
                >
                  <div className="flex items-start justify-between gap-3 mb-2.5">
                    <div className="flex items-start gap-3">
                      {/* Photo-initial avatar */}
                      <div className="relative w-14 h-14 rounded-2xl overflow-hidden shrink-0 border border-[#D6E3DE] bg-[#E7F0EC]">
                        {doc.image ? (
                          <img
                            src={doc.image}
                            alt={doc.name}
                            onError={(e) => {
                              e.currentTarget.style.display = 'none'
                              e.currentTarget.nextElementSibling?.classList.remove('hidden')
                            }}
                            className="w-full h-full object-cover"
                          />
                        ) : null}
                        <div className={`w-full h-full flex items-center justify-center font-extrabold text-[#137A6E] text-base ${doc.image ? 'hidden' : ''}`}>
                          {doc.initials || doc.name.split(' ').map(n => n[0]).join('')}
                        </div>
                      </div>

                      {/* Details */}
                      <div>
                        <div className="flex items-center gap-1.5">
                          <h3 className="text-sm font-extrabold text-[#0F3D3E] group-hover:text-[#137A6E] transition-colors">
                            {doc.name}
                          </h3>
                        </div>
                        <p className="text-xs font-semibold text-[#1A8A7D]">
                          {doc.specialty}
                        </p>

                        <div className="flex items-center gap-2 mt-1 text-xs text-[#52686A]">
                          <span className="flex items-center gap-1 font-bold text-[#17302F]">
                            <Star className="w-3.5 h-3.5 fill-[#E5A93C] text-[#E5A93C]" />
                            {doc.rating}
                          </span>
                          <span className="text-[11px] text-[#52686A]">
                            ({doc.reviewCount})
                          </span>
                          <span>•</span>
                          <span className="text-[11px] text-[#52686A]">
                            {doc.experience}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Favorite Heart */}
                    <button
                      onClick={(e) => toggleFavorite(doc.id, e)}
                      className="p-1.5 text-[#82999B] hover:text-[#C73E1D] transition-colors"
                      aria-label="Add to favorites"
                    >
                      <Heart
                        className={`w-4 h-4 ${
                          isFav ? 'fill-[#C73E1D] text-[#C73E1D]' : ''
                        }`}
                      />
                    </button>
                  </div>

                  {/* Hospital & Location */}
                  <div className="flex items-center gap-1.5 text-xs text-[#52686A] mb-3">
                    <MapPin className="w-3.5 h-3.5 text-[#137A6E] shrink-0" />
                    <span className="truncate">{doc.hospital}</span>
                  </div>

                  {/* Footer: Distance, Fee & Book Action */}
                  <div className="pt-2.5 border-t border-[#D6E3DE]/70 flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <span className="text-xs font-semibold text-[#52686A] bg-[#F7F5EF] px-2 py-0.5 rounded-md">
                        {doc.distanceText}
                      </span>
                      <span className="text-sm font-extrabold text-[#0F3D3E]">
                        ₹{doc.fee}
                      </span>
                    </div>

                    <button
                      onClick={() => handleSelectDoctor(doc)}
                      className="px-4 py-2 bg-[#137A6E] hover:bg-[#0F3D3E] text-white text-xs font-bold rounded-xl transition-all shadow-sm"
                    >
                      Book
                    </button>
                  </div>
                </div>
              )
            })}
          </div>
        )}

      </div>
    </div>
  )
}
