import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Search,
  Thermometer,
  Activity,
  Brain,
  Wind,
  CalendarHeart,
  Baby,
  Sparkles,
  Bone,
  HeartPulse,
  Footprints,
  ShieldAlert,
  Accessibility,
  AlertTriangle,
  Flame,
  Check,
  X,
  ArrowRight,
  RotateCcw,
} from 'lucide-react'
import Header from '../components/Header'
import { SYMPTOMS } from '../data'
import { useApp } from '../context/AppContext'
import { t } from '../i18n'

export default function SymptomScreen() {
  const navigate = useNavigate()
  const { selectedSymptoms, toggleSymptom, removeSymptom, clearSymptoms, language } = useApp()
  const [searchTerm, setSearchTerm] = useState('')

  const getSymptomIcon = (iconName, isUrgent, isSelected) => {
    const iconClass = `w-5 h-5 ${
      isSelected
        ? isUrgent ? 'text-[#C73E1D]' : 'text-[#137A6E]'
        : isUrgent ? 'text-[#C73E1D]' : 'text-[#52686A]'
    }`

    switch (iconName) {
      case 'Thermometer':
        return <Thermometer className={iconClass} />
      case 'Activity':
        return <Activity className={iconClass} />
      case 'Brain':
        return <Brain className={iconClass} />
      case 'Wind':
        return <Wind className={iconClass} />
      case 'CalendarHeart':
        return <CalendarHeart className={iconClass} />
      case 'Baby':
        return <Baby className={iconClass} />
      case 'Sparkles':
        return <Sparkles className={iconClass} />
      case 'Bone':
        return <Bone className={iconClass} />
      case 'HeartPulse':
        return <HeartPulse className={iconClass} />
      case 'Footprints':
        return <Footprints className={iconClass} />
      case 'ShieldAlert':
        return <ShieldAlert className={iconClass} />
      case 'Accessibility':
        return <Accessibility className={iconClass} />
      case 'AlertTriangle':
        return <AlertTriangle className={iconClass} />
      case 'Flame':
        return <Flame className={iconClass} />
      default:
        return <Activity className={iconClass} />
    }
  }

  const filteredSymptoms = SYMPTOMS.filter((symptom) => {
    const localizedLabel = t(symptom.id, language) || symptom.label
    return (
      symptom.label.toLowerCase().includes(searchTerm.toLowerCase()) ||
      localizedLabel.toLowerCase().includes(searchTerm.toLowerCase()) ||
      symptom.description.toLowerCase().includes(searchTerm.toLowerCase())
    )
  })

  const selectedItems = SYMPTOMS.filter(s => selectedSymptoms.includes(s.id))
  const hasUrgentSelected = selectedItems.some(s => s.isUrgent)

  const handleNext = () => {
    if (selectedSymptoms.length > 0) {
      navigate('/specialist')
    }
  }

  return (
    <div className="flex-1 flex flex-col justify-between bg-[#F7F5EF] select-none">
      {/* Top Header */}
      <Header title={t('symptomGuide', language)} backTo="/home" />

      {/* Main scrollable list */}
      <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
        
        {/* Title & Instructions */}
        <div>
          <h2 className="text-xl font-extrabold font-heading text-[#0F3D3E]">
            {t('symptomTitle', language)}
          </h2>
          <p className="text-xs text-[#52686A] mt-0.5">
            {t('symptomSub', language)}
          </p>
        </div>

        {/* Search Bar */}
        <div className="relative">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder={t('symptomSearchPlaceholder', language)}
            className="w-full bg-white border border-[#D6E3DE] rounded-xl py-2.5 pl-10 pr-4 text-xs font-medium text-[#17302F] placeholder-[#82999B] focus:outline-none focus:border-[#137A6E]"
          />
          <Search className="w-4 h-4 text-[#52686A] absolute left-3 top-1/2 -translate-y-1/2" />
        </div>

        {/* Urgent warning notice */}
        {hasUrgentSelected && (
          <div className="p-3 bg-[#FDECE8] border border-[#F8B4A6] rounded-xl flex items-center gap-2.5 animate-pulse">
            <AlertTriangle className="w-5 h-5 text-[#C73E1D] shrink-0" />
            <p className="text-xs text-[#C73E1D] font-bold leading-tight">
              {t('urgentNotice', language)}
            </p>
          </div>
        )}

        {/* 3-column / 3x4 Grid of symptom tiles */}
        <div className="grid grid-cols-3 gap-2.5">
          {filteredSymptoms.map((symptom) => {
            const isSelected = selectedSymptoms.includes(symptom.id)
            const isUrgent = symptom.isUrgent
            const labelText = t(symptom.id, language) || symptom.label

            return (
              <button
                key={symptom.id}
                onClick={() => toggleSymptom(symptom.id)}
                className={`relative flex flex-col items-center justify-center p-3 rounded-2xl text-center transition-all duration-150 active:scale-95 min-h-[96px] ${
                  isSelected
                    ? isUrgent
                      ? 'bg-[#FDECE8] border-2 border-[#C73E1D] shadow-sm'
                      : 'bg-[#E7F0EC] border-2 border-[#137A6E] shadow-sm'
                    : isUrgent
                    ? 'bg-white border border-[#F8B4A6] hover:bg-[#FDECE8]/40'
                    : 'bg-white border border-[#D6E3DE] hover:border-[#137A6E]/50'
                }`}
              >
                {/* Active check pill */}
                {isSelected && (
                  <div
                    className={`absolute top-1.5 right-1.5 w-4 h-4 rounded-full flex items-center justify-center text-white ${
                      isUrgent ? 'bg-[#C73E1D]' : 'bg-[#137A6E]'
                    }`}
                  >
                    <Check className="w-2.5 h-2.5 stroke-[3]" />
                  </div>
                )}

                {/* Urgent indicator label */}
                {isUrgent && !isSelected && (
                  <span className="absolute top-1.5 right-1.5 text-[9px] font-bold text-[#C73E1D] bg-[#FDECE8] px-1 rounded">
                    Urgent
                  </span>
                )}

                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center mb-1.5 ${
                    isSelected
                      ? isUrgent ? 'bg-[#F8B4A6]/60' : 'bg-white'
                      : isUrgent ? 'bg-[#FDECE8]' : 'bg-[#E7F0EC]'
                  }`}
                >
                  {getSymptomIcon(symptom.icon, isUrgent, isSelected)}
                </div>

                <span
                  className={`text-[11px] leading-tight line-clamp-2 ${
                    isSelected
                      ? isUrgent ? 'font-extrabold text-[#C73E1D]' : 'font-extrabold text-[#0F3D3E]'
                      : isUrgent ? 'font-bold text-[#C73E1D]' : 'font-bold text-[#17302F]'
                  }`}
                >
                  {labelText}
                </span>
              </button>
            )
          })}
        </div>

      </div>

      {/* Bottom Sticky Section: Selected Chips & Next button */}
      <div className="bg-white border-t border-[#D6E3DE] p-4 shadow-lg shrink-0 space-y-3">
        {/* Selected symptoms row */}
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-[#0F3D3E]">
            {t('selected', language)} ({selectedSymptoms.length})
          </span>
          {selectedSymptoms.length > 0 && (
            <button
              onClick={clearSymptoms}
              className="text-xs font-bold text-[#52686A] hover:text-[#C73E1D] flex items-center gap-1"
            >
              <RotateCcw className="w-3 h-3" /> {t('clearAll', language)}
            </button>
          )}
        </div>

        {/* Selected chips container */}
        <div className="flex items-center gap-1.5 overflow-x-auto py-1 no-scrollbar min-h-[32px]">
          {selectedItems.length === 0 ? (
            <span className="text-xs text-[#82999B] italic">
              {t('tapToSelect', language)}
            </span>
          ) : (
            selectedItems.map((item) => (
              <span
                key={item.id}
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold shrink-0 ${
                  item.isUrgent
                    ? 'bg-[#FDECE8] text-[#C73E1D] border border-[#F8B4A6]'
                    : 'bg-[#E7F0EC] text-[#137A6E] border border-[#6FD3BF]/60'
                }`}
              >
                {t(item.id, language) || item.label}
                <button
                  onClick={() => removeSymptom(item.id)}
                  className="hover:opacity-70 p-0.5"
                  aria-label={`Remove ${item.label}`}
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            ))
          )}
        </div>

        {/* Action Button */}
        <button
          onClick={handleNext}
          disabled={selectedSymptoms.length === 0}
          className={`tap-target w-full rounded-xl font-bold text-base flex items-center justify-center gap-2 shadow-sm transition-all duration-200 ${
            selectedSymptoms.length > 0
              ? hasUrgentSelected
                ? 'bg-[#C73E1D] hover:bg-[#a53216] text-white active:scale-[0.98]'
                : 'bg-[#137A6E] hover:bg-[#0F3D3E] text-white active:scale-[0.98]'
              : 'bg-[#D6E3DE] text-[#82999B] cursor-not-allowed'
          }`}
        >
          <span>{hasUrgentSelected ? t('reviewEmergency', language) : t('next', language)}</span>
          <ArrowRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  )
}
