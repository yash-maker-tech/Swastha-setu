import React from 'react'
import { useNavigate } from 'react-router-dom'
import { Check, Globe, ArrowRight } from 'lucide-react'
import Header from '../components/Header'
import { LANGUAGES } from '../data'
import { useApp } from '../context/AppContext'

export default function LanguageScreen() {
  const navigate = useNavigate()
  const { language, setLanguage } = useApp()

  const handleSelect = (code) => {
    setLanguage(code)
  }

  return (
    <div className="flex-1 flex flex-col justify-between bg-[#F7F5EF] select-none">
      {/* Top Header */}
      <Header title="Language / भाषा" backTo="/profile" />

      {/* Main List */}
      <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
        
        <div>
          <h2 className="text-xl font-extrabold font-heading text-[#0F3D3E]">
            Choose Your Language
          </h2>
          <p className="text-xs text-[#52686A] mt-0.5">
            Full translations available in English, हिंदी, and मराठी.
          </p>
        </div>

        {/* Language Options List */}
        <div className="bg-white border border-[#D6E3DE] rounded-2xl overflow-hidden shadow-sm divide-y divide-[#D6E3DE]/60">
          {LANGUAGES.map((lang) => {
            const isSelected = language === lang.code
            const hasFullSupport = ['en', 'hi', 'mr'].includes(lang.code)

            return (
              <button
                key={lang.code}
                onClick={() => handleSelect(lang.code)}
                className={`w-full p-4 flex items-center justify-between text-left transition-colors ${
                  isSelected ? 'bg-[#E7F0EC]/80' : 'hover:bg-[#F7F5EF]'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span className="text-xl">{lang.flag}</span>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-[#0F3D3E]">
                        {lang.native}
                      </span>
                      {hasFullSupport && (
                        <span className="text-[10px] bg-[#6FD3BF]/30 text-[#0F3D3E] font-bold px-1.5 py-0.2 rounded">
                          Active
                        </span>
                      )}
                    </div>
                    <span className="text-xs text-[#52686A]">
                      {lang.name}
                    </span>
                  </div>
                </div>

                <div
                  className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all ${
                    isSelected
                      ? 'border-[#137A6E] bg-[#137A6E] text-white'
                      : 'border-[#82999B] bg-white'
                  }`}
                >
                  {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                </div>
              </button>
            )
          })}
        </div>

        {/* Note banner */}
        <div className="p-4 rounded-2xl bg-[#E7F0EC] border border-[#6FD3BF]/50 text-center space-y-1">
          <Globe className="w-5 h-5 text-[#137A6E] mx-auto mb-1" />
          <p className="text-xs font-bold text-[#0F3D3E]">
            Healthcare for everyone, in every language.
          </p>
          <p className="text-[11px] text-[#52686A]">
            Tamil, Telugu, Bengali and Kannada interface fallback to English in current release.
          </p>
        </div>

      </div>

      {/* Sticky Bottom Confirm */}
      <div className="bg-white border-t border-[#D6E3DE] p-4 shadow-lg shrink-0">
        <button
          onClick={() => navigate('/home')}
          className="tap-target w-full bg-[#137A6E] hover:bg-[#0F3D3E] active:scale-[0.98] text-white font-bold text-base rounded-xl flex items-center justify-center gap-2 shadow-md transition-all duration-200"
        >
          <span>Save & Go to Home</span>
          <ArrowRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  )
}
