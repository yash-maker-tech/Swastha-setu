import React, { useState } from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import {
  Star,
  CheckCircle2,
  ShieldCheck,
  ArrowRight,
  Sparkles,
} from 'lucide-react'
import Header from '../components/Header'
import { useApp } from '../context/AppContext'

export default function ReviewScreen() {
  const navigate = useNavigate()
  const location = useLocation()
  const { chosenDoctor, submitReview } = useApp()

  const appointmentData = location.state?.appointment || null

  const targetDoctor = appointmentData
    ? {
        id: appointmentData.doctorId,
        name: appointmentData.doctorName,
        specialty: appointmentData.specialty,
        hospital: appointmentData.hospital,
        image: chosenDoctor?.image,
        appointmentId: appointmentData.id,
      }
    : {
        id: chosenDoctor.id,
        name: chosenDoctor.name,
        specialty: chosenDoctor.specialty,
        hospital: chosenDoctor.hospital,
        image: chosenDoctor.image,
        appointmentId: 'apt-completed-1',
      }

  const [rating, setRating] = useState(5)
  const [hoverRating, setHoverRating] = useState(0)
  const [comment, setComment] = useState('')
  const [selectedTags, setSelectedTags] = useState(['Excellent care', 'Polite'])
  const [submitted, setSubmitted] = useState(false)

  const tags = [
    'Excellent care',
    'Polite',
    'Explained well',
    'Clean clinic',
    'Short waiting time',
    'Affordable',
  ]

  const toggleTag = (tag) => {
    setSelectedTags(prev =>
      prev.includes(tag) ? prev.filter(t => t !== tag) : [...prev, tag]
    )
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    submitReview({
      doctorId: targetDoctor.id,
      doctorName: targetDoctor.name,
      rating,
      comment,
      tags: selectedTags,
      appointmentId: targetDoctor.appointmentId,
    })
    setSubmitted(true)
    setTimeout(() => {
      navigate('/appointments')
    }, 1800)
  }

  return (
    <div className="flex-1 flex flex-col justify-between bg-[#F7F5EF] select-none">
      {/* Top Header */}
      <Header title="After-Visit Review" backTo="/appointments" />

      {/* Main Form Content */}
      <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
        
        {submitted ? (
          <div className="my-auto py-16 flex flex-col items-center text-center space-y-3">
            <div className="w-16 h-16 rounded-full bg-[#E7F0EC] border-2 border-[#137A6E] flex items-center justify-center animate-bounce">
              <CheckCircle2 className="w-9 h-9 text-[#137A6E]" />
            </div>
            <h3 className="text-xl font-extrabold font-heading text-[#0F3D3E]">
              Review Submitted!
            </h3>
            <p className="text-xs text-[#52686A] max-w-xs">
              Thank you! Your verified visit review has been recorded to help other patients.
            </p>
          </div>
        ) : (
          <>
            <div>
              <h2 className="text-xl font-extrabold font-heading text-[#0F3D3E]">
                How was your experience?
              </h2>
              <p className="text-xs text-[#52686A] mt-0.5">
                Your feedback helps others in Pune find trusted healthcare.
              </p>
            </div>

            {/* Doctor Info Card */}
            <div className="bg-white border border-[#D6E3DE] rounded-2xl p-3.5 shadow-sm flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-[#E7F0EC] overflow-hidden shrink-0 border border-[#D6E3DE]">
                <img
                  src={targetDoctor.image}
                  alt={targetDoctor.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <h3 className="text-sm font-extrabold text-[#0F3D3E]">
                  {targetDoctor.name}
                </h3>
                <p className="text-xs text-[#1A8A7D] font-semibold">
                  {targetDoctor.specialty} • {targetDoctor.hospital}
                </p>
              </div>
            </div>

            {/* Star Rating Selector */}
            <div className="bg-white border border-[#D6E3DE] rounded-2xl p-4 shadow-sm text-center space-y-2">
              <span className="text-xs font-bold text-[#0F3D3E] block">
                Rate your consultation experience
              </span>
              <div className="flex items-center justify-center gap-2 py-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setRating(star)}
                    onMouseEnter={() => setHoverRating(star)}
                    onMouseLeave={() => setHoverRating(0)}
                    className="p-1 hover:scale-110 active:scale-95 transition-transform"
                    aria-label={`Rate ${star} stars`}
                  >
                    <Star
                      className={`w-8 h-8 ${
                        star <= (hoverRating || rating)
                          ? 'fill-[#E5A93C] text-[#E5A93C]'
                          : 'text-[#D6E3DE]'
                      }`}
                    />
                  </button>
                ))}
              </div>
              <span className="text-xs font-semibold text-[#137A6E]">
                {rating === 5 && 'Excellent care!'}
                {rating === 4 && 'Very good experience'}
                {rating === 3 && 'Average experience'}
                {rating <= 2 && 'Needs improvement'}
              </span>
            </div>

            {/* Quick Experience Tags */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-[#0F3D3E] block px-1">
                What went well? (Select all that apply)
              </label>
              <div className="flex flex-wrap gap-1.5">
                {tags.map((tag) => {
                  const selected = selectedTags.includes(tag)
                  return (
                    <button
                      key={tag}
                      type="button"
                      onClick={() => toggleTag(tag)}
                      className={`px-3 py-1.5 rounded-full text-xs font-bold transition-all ${
                        selected
                          ? 'bg-[#137A6E] text-white shadow-sm'
                          : 'bg-white border border-[#D6E3DE] text-[#52686A] hover:border-[#137A6E]'
                      }`}
                    >
                      {tag}
                    </button>
                  )
                })}
              </div>
            </div>

            {/* Feedback textarea */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-[#0F3D3E] block px-1">
                Write a review (optional)
              </label>
              <textarea
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder="Share your experience with the doctor and clinic..."
                rows={3}
                className="w-full bg-white border border-[#D6E3DE] rounded-2xl p-3 text-xs text-[#17302F] placeholder-[#82999B] focus:outline-none focus:border-[#137A6E]"
              />
            </div>

            {/* Mandatory policy note required by user: "Only reviews from completed visits count toward ranking." */}
            <div className="p-3 bg-[#E7F0EC] border border-[#6FD3BF]/50 rounded-xl flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#137A6E] shrink-0" />
              <p className="text-[11px] text-[#17302F] leading-tight font-medium">
                Only reviews from completed visits count toward ranking.
              </p>
            </div>
          </>
        )}

      </div>

      {/* Sticky Bottom Submit Button */}
      {!submitted && (
        <div className="bg-white border-t border-[#D6E3DE] p-4 shadow-lg shrink-0">
          <button
            onClick={handleSubmit}
            className="tap-target w-full bg-[#137A6E] hover:bg-[#0F3D3E] active:scale-[0.98] text-white font-bold text-base rounded-xl flex items-center justify-center gap-2 shadow-md transition-all duration-200"
          >
            <span>Submit Review</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      )}
    </div>
  )
}
