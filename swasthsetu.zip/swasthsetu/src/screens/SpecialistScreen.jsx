import React from 'react'
import { useNavigate } from 'react-router-dom'
import {
  AlertTriangle,
  PhoneCall,
  ShieldCheck,
  ArrowRight,
  Info,
  ChevronRight,
  Stethoscope,
  Sparkles,
  Ambulance,
} from 'lucide-react'
import Header from '../components/Header'
import { determineSpecialist, SYMPTOMS } from '../data'
import { useApp } from '../context/AppContext'

export default function SpecialistScreen() {
  const navigate = useNavigate()
  const { selectedSymptoms } = useApp()

  const recommendation = determineSpecialist(selectedSymptoms)
  const isUrgent = recommendation.isUrgent

  // Get selected symptom objects
  const selectedList = SYMPTOMS.filter(s => selectedSymptoms.includes(s.id))

  return (
    <div className="flex-1 flex flex-col justify-between bg-[#F7F5EF] select-none">
      {/* Top Header */}
      <Header title="Specialist Suggestion" backTo="/symptoms" />

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
        
        {/* Step Indicator */}
        <div className="flex items-center gap-1.5 justify-center py-1">
          <span className="w-8 h-1.5 rounded-full bg-[#137A6E]"></span>
          <span className="w-8 h-1.5 rounded-full bg-[#137A6E]"></span>
          <span className="w-8 h-1.5 rounded-full bg-[#D6E3DE]"></span>
        </div>

        {/* Selected Symptoms Pills */}
        <div className="bg-white border border-[#D6E3DE] rounded-2xl p-3 shadow-sm">
          <span className="text-[11px] font-bold text-[#52686A] uppercase tracking-wider block mb-1.5">
            Based on your selected symptoms:
          </span>
          <div className="flex flex-wrap gap-1.5">
            {selectedList.length === 0 ? (
              <span className="text-xs text-[#82999B]">General health check</span>
            ) : (
              selectedList.map(s => (
                <span
                  key={s.id}
                  className={`text-xs font-bold px-2.5 py-0.5 rounded-full ${
                    s.isUrgent
                      ? 'bg-[#FDECE8] text-[#C73E1D] border border-[#F8B4A6]'
                      : 'bg-[#E7F0EC] text-[#137A6E]'
                  }`}
                >
                  {s.label}
                </span>
              ))
            )}
          </div>
        </div>

        {/* URGENT RED FLAG STATE */}
        {isUrgent ? (
          <div className="space-y-4">
            {/* Urgent Red Banner */}
            <div className="bg-[#FDECE8] border-2 border-[#C73E1D] rounded-2xl p-5 shadow-md">
              <div className="flex items-center gap-3 text-[#C73E1D] mb-2">
                <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center border border-[#F8B4A6]">
                  <AlertTriangle className="w-6 h-6 text-[#C73E1D]" />
                </div>
                <h3 className="text-lg font-extrabold font-heading">
                  This may be urgent.
                </h3>
              </div>

              <p className="text-sm font-semibold text-[#17302F] leading-snug mb-3">
                Chest pain or difficulty breathing requires immediate emergency attention. Do not delay medical care.
              </p>

              <div className="p-3 bg-white/80 rounded-xl border border-[#F8B4A6] mb-4">
                <p className="text-xs text-[#52686A] leading-tight">
                  Please call local emergency services immediately or visit the nearest emergency casualty room.
                </p>
              </div>

              {/* Call Emergency Services Button */}
              <a
                href="tel:112"
                className="tap-target w-full bg-[#C73E1D] hover:bg-[#a53216] active:scale-[0.98] text-white font-bold text-base rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-[#C73E1D]/25 transition-all duration-200"
              >
                <PhoneCall className="w-5 h-5" />
                <span>Call Emergency (112 / 108)</span>
              </a>
            </div>

            {/* Quick Ambulance Button */}
            <button
              onClick={() => navigate('/emergency')}
              className="tap-target w-full bg-white border border-[#F8B4A6] text-[#C73E1D] font-bold text-sm rounded-xl flex items-center justify-center gap-2 shadow-sm hover:bg-[#FDECE8]"
            >
              <Ambulance className="w-5 h-5 text-[#C73E1D]" />
              <span>Open Ambulance Dispatch</span>
            </button>
          </div>
        ) : (
          /* NORMAL SPECIALIST RECOMMENDATION FLOW */
          <div className="space-y-4">
            {/* Big Hero Card */}
            <div className="bg-gradient-to-br from-[#0F3D3E] to-[#137A6E] rounded-3xl p-5 text-white shadow-xl relative overflow-hidden">
              {/* Background ambient ring */}
              <div className="absolute -top-10 -right-10 w-40 h-40 bg-white/10 rounded-full blur-xl pointer-events-none" />

              <div className="flex items-center gap-2 mb-3">
                <span className="px-2.5 py-0.5 rounded-full bg-[#6FD3BF]/25 text-[#6FD3BF] text-[11px] font-extrabold uppercase tracking-wider border border-[#6FD3BF]/30">
                  {recommendation.badge || 'Recommended Specialist'}
                </span>
              </div>

              <div className="flex items-start justify-between gap-4 mb-3">
                <div>
                  <h3 className="text-2xl font-extrabold font-heading text-white tracking-tight mb-1">
                    {recommendation.title}
                  </h3>
                  <p className="text-xs text-[#E7F0EC]/90 leading-relaxed font-medium">
                    {recommendation.description}
                  </p>
                </div>

                <div className="w-16 h-16 rounded-2xl overflow-hidden shrink-0 border-2 border-white/30 bg-white/10 shadow-md">
                  <img
                    src={recommendation.avatar}
                    alt={recommendation.title}
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>

              {/* Why this recommendation */}
              <div className="pt-3 border-t border-white/15 flex items-center gap-2 text-xs text-[#E7F0EC]">
                <Sparkles className="w-4 h-4 text-[#6FD3BF] shrink-0" />
                <span>{recommendation.whyThisDoctor}</span>
              </div>
            </div>

            {/* Other Relevant Specialists */}
            {recommendation.otherSpecialists && recommendation.otherSpecialists.length > 0 && (
              <div>
                <h4 className="text-sm font-bold font-heading text-[#0F3D3E] mb-2 px-1">
                  Other relevant specialists (if needed)
                </h4>
                <div className="space-y-2">
                  {recommendation.otherSpecialists.map((spec, idx) => (
                    <div
                      key={idx}
                      className="bg-white border border-[#D6E3DE] rounded-2xl p-3 flex items-center justify-between shadow-sm hover:border-[#137A6E]/50 transition-colors"
                    >
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-xl bg-[#E7F0EC] flex items-center justify-center shrink-0">
                          <Stethoscope className="w-4 h-4 text-[#137A6E]" />
                        </div>
                        <div>
                          <span className="text-xs font-bold text-[#17302F] block">
                            {spec.name}
                          </span>
                          <span className="text-[11px] text-[#52686A]">
                            {spec.reason}
                          </span>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-[#82999B] shrink-0" />
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Crucial Ethical Disclaimer Banner */}
            <div className="p-3.5 bg-[#E7F0EC] border border-[#6FD3BF]/50 rounded-2xl flex items-start gap-2.5">
              <ShieldCheck className="w-4 h-4 text-[#137A6E] shrink-0 mt-0.5" />
              <p className="text-xs text-[#17302F] leading-relaxed">
                <strong className="font-bold text-[#0F3D3E]">Guidance only.</strong> This is not a medical diagnosis or disease prediction. Always consult a certified healthcare professional.
              </p>
            </div>
          </div>
        )}

      </div>

      {/* Sticky Bottom Actions */}
      <div className="bg-white border-t border-[#D6E3DE] p-4 shadow-lg shrink-0">
        {!isUrgent ? (
          <button
            onClick={() => navigate('/filters')}
            className="tap-target w-full bg-[#137A6E] hover:bg-[#0F3D3E] active:scale-[0.98] text-white font-bold text-base rounded-xl flex items-center justify-center gap-2 shadow-md transition-all duration-200"
          >
            <span>View Available Doctors</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        ) : (
          <button
            onClick={() => navigate('/home')}
            className="tap-target w-full bg-white border border-[#D6E3DE] hover:bg-[#F7F5EF] text-[#52686A] font-bold text-sm rounded-xl flex items-center justify-center gap-2"
          >
            <span>Back to Home</span>
          </button>
        )}
      </div>
    </div>
  )
}
