import React, { useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import {
  Star,
  MapPin,
  Clock,
  Heart,
  Calendar,
  ShieldCheck,
  ArrowRight,
  GraduationCap,
  Building,
  CheckCircle2,
} from 'lucide-react'
import Header from '../components/Header'
import { DOCTORS } from '../data'
import { useApp } from '../context/AppContext'

export default function DoctorProfileScreen() {
  const navigate = useNavigate()
  const { id } = useParams()
  const { chosenDoctorId, bookAppointment } = useApp()

  const docId = id || chosenDoctorId
  const doctor = DOCTORS.find(d => d.id === docId) || DOCTORS[0]

  const [activeTab, setActiveTab] = useState('about')
  const [selectedDayIndex, setSelectedDayIndex] = useState(0)
  
  // Available schedule (today + next 3 days)
  const currentSchedule = doctor.schedule || [
    { dateLabel: 'Today, 31 Oct', slots: ['10:00 AM', '11:30 AM', '02:00 PM', '04:30 PM', '06:00 PM'] },
    { dateLabel: 'Sun, 1 Nov', slots: ['10:30 AM', '12:00 PM', '03:30 PM', '05:00 PM'] },
    { dateLabel: 'Mon, 2 Nov', slots: ['09:30 AM', '11:00 AM', '02:30 PM', '04:00 PM'] },
    { dateLabel: 'Tue, 3 Nov', slots: ['10:00 AM', '01:00 PM', '04:00 PM', '05:30 PM'] },
  ]

  const activeDay = currentSchedule[selectedDayIndex] || currentSchedule[0]
  const [selectedSlot, setSelectedSlot] = useState(activeDay.slots[0] || '11:00 AM')
  const [isFav, setIsFav] = useState(false)

  const handleBooking = () => {
    bookAppointment({
      doctor,
      date: activeDay.dateLabel,
      slot: selectedSlot,
    })
    navigate('/confirmation')
  }

  return (
    <div className="flex-1 flex flex-col justify-between bg-[#F7F5EF] select-none">
      {/* Top Header */}
      <Header
        title="Doctor Profile"
        backTo="/doctors"
        rightAction={
          <button
            onClick={() => setIsFav(!isFav)}
            className="w-9 h-9 rounded-full bg-white border border-[#D6E3DE] flex items-center justify-center text-[#52686A] hover:text-[#C73E1D] transition-colors"
            aria-label="Add to favorites"
          >
            <Heart
              className={`w-4 h-4 ${
                isFav ? 'fill-[#C73E1D] text-[#C73E1D]' : ''
              }`}
            />
          </button>
        }
      />

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
        
        {/* Doctor Summary Card with photo-initial avatar */}
        <div className="bg-white border border-[#D6E3DE] rounded-2xl p-4 shadow-sm flex items-center gap-4">
          <div className="relative w-20 h-20 rounded-2xl overflow-hidden shrink-0 border border-[#D6E3DE] bg-[#E7F0EC]">
            {doctor.image ? (
              <img
                src={doctor.image}
                alt={doctor.name}
                onError={(e) => {
                  e.currentTarget.style.display = 'none'
                  e.currentTarget.nextElementSibling?.classList.remove('hidden')
                }}
                className="w-full h-full object-cover"
              />
            ) : null}
            <div className={`w-full h-full flex items-center justify-center font-extrabold text-[#137A6E] text-2xl ${doctor.image ? 'hidden' : ''}`}>
              {doctor.initials || doctor.name.split(' ').map(n => n[0]).join('')}
            </div>
          </div>

          <div>
            <h2 className="text-base font-extrabold font-heading text-[#0F3D3E]">
              {doctor.name}
            </h2>
            <p className="text-xs font-semibold text-[#1A8A7D]">
              {doctor.specialty}
            </p>

            <div className="flex items-center gap-1.5 mt-1.5">
              <Star className="w-3.5 h-3.5 fill-[#E5A93C] text-[#E5A93C]" />
              <span className="text-xs font-bold text-[#0F3D3E]">
                {doctor.rating}
              </span>
              <span className="text-xs text-[#52686A]">
                ({doctor.reviewCount} verified reviews)
              </span>
            </div>

            <p className="text-xs text-[#52686A] mt-1 font-medium">
              {doctor.experience}
            </p>
          </div>
        </div>

        {/* Tab switcher: About / Reviews / Location */}
        <div className="flex border-b border-[#D6E3DE]">
          {[
            { id: 'about', label: 'About' },
            { id: 'reviews', label: `Reviews (${doctor.reviews?.length || 3})` },
            { id: 'location', label: 'Location' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 py-2 text-xs font-bold text-center border-b-2 transition-all ${
                activeTab === tab.id
                  ? 'border-[#137A6E] text-[#137A6E]'
                  : 'border-transparent text-[#52686A] hover:text-[#0F3D3E]'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab 1: About */}
        {activeTab === 'about' && (
          <div className="space-y-3">
            <div className="bg-white border border-[#D6E3DE] rounded-2xl p-4 shadow-sm space-y-2.5">
              <h3 className="text-xs font-extrabold text-[#0F3D3E] uppercase tracking-wider">
                Doctor Overview
              </h3>
              <p className="text-xs text-[#52686A] leading-relaxed">
                {doctor.about}
              </p>
              
              <div className="pt-2 border-t border-[#D6E3DE]/60 space-y-1.5 text-xs">
                <div className="flex items-start gap-2">
                  <GraduationCap className="w-4 h-4 text-[#137A6E] shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-[#0F3D3E]">Qualifications: </strong>
                    <span className="text-[#52686A]">{doctor.qualifications}</span>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <Building className="w-4 h-4 text-[#137A6E] shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-[#0F3D3E]">Clinic/Hospital: </strong>
                    <span className="text-[#52686A]">{doctor.hospital} ({doctor.clinicType})</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Consultation Fee Card */}
            <div className="bg-white border border-[#D6E3DE] rounded-2xl p-4 shadow-sm flex items-center justify-between">
              <div>
                <span className="text-xs text-[#52686A] block">Consultation Fee</span>
                <span className="text-[11px] text-[#82999B]">Pay at the clinic desk</span>
              </div>
              <span className="text-lg font-extrabold text-[#0F3D3E]">
                ₹{doctor.fee}
              </span>
            </div>
          </div>
        )}

        {/* Tab 2: Reviews (3 mock reviews with "Verified visit" badge) */}
        {activeTab === 'reviews' && (
          <div className="bg-white border border-[#D6E3DE] rounded-2xl p-4 shadow-sm space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-[#D6E3DE]">
              <span className="text-xs font-bold text-[#0F3D3E]">
                Verified Patient Reviews
              </span>
              <span className="text-[11px] text-[#137A6E] font-bold">
                ⭐ {doctor.rating} / 5.0
              </span>
            </div>

            <div className="space-y-3">
              {(doctor.reviews || []).map((rev, index) => (
                <div key={index} className="p-3 bg-[#F7F5EF] rounded-xl text-xs space-y-1.5 border border-[#D6E3DE]/60">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-[#0F3D3E]">{rev.author}</span>
                    <span className="text-[10px] text-[#52686A]">{rev.date}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <div className="flex gap-0.5">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-3 h-3 ${
                            i < Math.floor(rev.rating)
                              ? 'fill-[#E5A93C] text-[#E5A93C]'
                              : 'text-[#D6E3DE]'
                          }`}
                        />
                      ))}
                    </div>
                    {rev.verified && (
                      <span className="inline-flex items-center gap-1 text-[10px] font-bold text-[#137A6E] bg-[#E7F0EC] px-2 py-0.5 rounded-full">
                        <CheckCircle2 className="w-2.5 h-2.5" />
                        Verified visit
                      </span>
                    )}
                  </div>

                  <p className="text-[#52686A] leading-snug">
                    "{rev.comment}"
                  </p>
                </div>
              ))}
            </div>

            <p className="text-[11px] text-[#82999B] text-center pt-1">
              Only reviews from completed visits count toward ranking.
            </p>
          </div>
        )}

        {/* Tab 3: Location */}
        {activeTab === 'location' && (
          <div className="bg-white border border-[#D6E3DE] rounded-2xl p-4 shadow-sm space-y-3">
            <div className="flex items-start gap-2.5 text-xs">
              <MapPin className="w-4 h-4 text-[#137A6E] shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-[#0F3D3E]">{doctor.hospital}</p>
                <p className="text-[#52686A] text-[11px] mt-0.5">
                  Wagholi, Pune, Maharashtra 412207
                </p>
                <p className="text-[#137A6E] text-xs font-semibold mt-1">
                  {doctor.distanceText} from your detected location
                </p>
              </div>
            </div>

            <div className="h-32 bg-[#E7F0EC] rounded-xl flex flex-col items-center justify-center text-xs text-[#137A6E] font-bold border border-[#6FD3BF]/40 p-3 text-center">
              <span>Interactive Map View</span>
              <span className="text-[11px] text-[#52686A] font-normal mt-1">
                Directions: 7 mins via Nagar Road
              </span>
            </div>
          </div>
        )}

        {/* Slot Selection (Date chips + Time chips) */}
        <div className="bg-white border border-[#D6E3DE] rounded-2xl p-4 shadow-sm space-y-3">
          <label className="text-xs font-bold text-[#0F3D3E] flex items-center gap-1.5">
            <Calendar className="w-4 h-4 text-[#137A6E]" />
            <span>Select Date & Time Slot</span>
          </label>

          {/* Date Chips (Today + next 3 days) */}
          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
            {currentSchedule.map((dayItem, idx) => {
              const active = selectedDayIndex === idx
              return (
                <button
                  key={idx}
                  onClick={() => {
                    setSelectedDayIndex(idx)
                    setSelectedSlot(dayItem.slots[0] || '11:00 AM')
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold shrink-0 transition-all ${
                    active
                      ? 'bg-[#137A6E] text-white shadow-sm'
                      : 'bg-[#E7F0EC] text-[#52686A] hover:bg-[#D6E3DE]'
                  }`}
                >
                  {dayItem.dateLabel}
                </button>
              )
            })}
          </div>

          {/* Time Slots (4-6 chips) */}
          <div className="grid grid-cols-3 gap-2 pt-1">
            {activeDay.slots.map((slot) => {
              const active = selectedSlot === slot
              return (
                <button
                  key={slot}
                  onClick={() => setSelectedSlot(slot)}
                  className={`py-2 px-1 text-center text-xs font-bold rounded-xl transition-all ${
                    active
                      ? 'bg-[#0F3D3E] text-white shadow-sm'
                      : 'bg-[#F7F5EF] border border-[#D6E3DE] text-[#17302F] hover:border-[#137A6E]'
                  }`}
                >
                  {slot}
                </button>
              )
            })}
          </div>
        </div>

      </div>

      {/* Sticky "Book Appointment" CTA Button */}
      <div className="bg-white border-t border-[#D6E3DE] p-4 shadow-lg shrink-0">
        <button
          onClick={handleBooking}
          className="tap-target w-full bg-[#137A6E] hover:bg-[#0F3D3E] active:scale-[0.98] text-white font-bold text-base rounded-xl flex items-center justify-center gap-2 shadow-md transition-all duration-200"
        >
          <span>Book Appointment ({selectedSlot})</span>
          <ArrowRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  )
}
